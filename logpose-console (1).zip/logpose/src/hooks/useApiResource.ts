import { useCallback, useEffect, useState } from 'react'
import { api, isAbort, parseApiError } from '../lib/api'
import type { ParsedApiError } from '../lib/api'

interface ApiResource<T> {
  data: T | null
  loading: boolean
  error: ParsedApiError | null
  /** Vuelve a pedir el recurso: es el boton "Reintentar". */
  reload: () => void
  /** Permite sustituir los datos sin pedirlos otra vez (p. ej. tras un PATCH). */
  replace: (value: T) => void
}

/**
 * GET de un recurso que se pide una vez, con sus tres estados y reintento.
 *
 * Para las pantallas con paginacion o scroll infinito no se usa: esas manejan
 * su propio estado porque acumulan paginas y necesitan proteccion extra
 * contra respuestas viejas.
 */
export function useApiResource<T>(path: string | null): ApiResource<T> {
  const [data, setData] = useState<T | null>(null)
  const [loading, setLoading] = useState(path !== null)
  const [error, setError] = useState<ParsedApiError | null>(null)
  const [reloadToken, setReloadToken] = useState(0)

  const reload = useCallback(() => {
    setReloadToken((value) => value + 1)
  }, [])

  useEffect(() => {
    if (path === null) {
      setLoading(false)
      return
    }

    const controller = new AbortController()
    setLoading(true)
    setError(null)

    api
      .get<T>(path, { signal: controller.signal })
      .then((response) => {
        setData(response.data)
        setError(null)
      })
      .catch((err: unknown) => {
        // Una peticion abortada es la limpieza del efecto, no un fallo.
        if (isAbort(err)) return
        setError(parseApiError(err))
      })
      .finally(() => {
        if (controller.signal.aborted) return
        setLoading(false)
      })

    return () => {
      controller.abort()
    }
  }, [path, reloadToken])

  const replace = useCallback((value: T) => {
    setData(value)
  }, [])

  return { data, loading, error, reload, replace }
}
