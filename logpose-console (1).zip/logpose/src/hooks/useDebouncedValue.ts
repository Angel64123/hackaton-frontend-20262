import { useEffect, useState } from 'react'

/**
 * Devuelve el valor solo cuando dejo de cambiar durante `delay` ms.
 * Asi la busqueda del CP2 no manda una request por cada tecla.
 */
export function useDebouncedValue<T>(value: T, delay: number): T {
  const [debounced, setDebounced] = useState(value)

  useEffect(() => {
    const timer = window.setTimeout(() => {
      setDebounced(value)
    }, delay)

    // Si el valor cambia antes de que venza el temporizador, se cancela y
    // vuelve a empezar: solo sobrevive la ultima pulsacion.
    return () => {
      window.clearTimeout(timer)
    }
  }, [value, delay])

  return debounced
}
