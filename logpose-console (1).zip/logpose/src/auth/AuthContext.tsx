import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react'
import type { ReactNode } from 'react'
import { api, clearToken, onUnauthorized, readToken, writeToken } from '../lib/api'
import type { LoginResponse, MeResponse, Team, User } from '../lib/types'

/**
 * `checking` existe para cumplir el CP1: al recargar no se puede mostrar el
 * login mientras se verifica el token, porque el usuario parpadearia fuera de
 * su sesion. Hasta que /auth/me responda, las rutas privadas muestran un splash.
 */
export type AuthStatus = 'checking' | 'authenticated' | 'anonymous'

interface AuthValue {
  status: AuthStatus
  user: User | null
  team: Team | null
  login: (email: string, password: string) => Promise<void>
  register: (teamName: string, email: string, password: string) => Promise<void>
  logout: () => void
}

const AuthContext = createContext<AuthValue | null>(null)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [status, setStatus] = useState<AuthStatus>(() => (readToken() ? 'checking' : 'anonymous'))
  const [user, setUser] = useState<User | null>(null)
  const [team, setTeam] = useState<Team | null>(null)

  const applySession = useCallback((nextUser: User, nextTeam: Team) => {
    setUser(nextUser)
    setTeam(nextTeam)
    setStatus('authenticated')
  }, [])

  const dropSession = useCallback(() => {
    clearToken()
    setUser(null)
    setTeam(null)
    setStatus('anonymous')
  }, [])

  // Restauracion de sesion al cargar la app: hay token guardado, pero puede
  // estar vencido o revocado, asi que se lo preguntamos al servidor.
  useEffect(() => {
    if (!readToken()) {
      setStatus('anonymous')
      return
    }

    let cancelled = false
    api
      .get<MeResponse>('/auth/me')
      .then((response) => {
        if (cancelled) return
        applySession(response.data.user, response.data.team)
      })
      .catch(() => {
        if (cancelled) return
        dropSession()
      })

    return () => {
      cancelled = true
    }
  }, [applySession, dropSession])

  // Si cualquier request responde 401 (sesion vencida), la app vuelve al login.
  useEffect(() => {
    return onUnauthorized(() => {
      setUser(null)
      setTeam(null)
      setStatus('anonymous')
    })
  }, [])

  const login = useCallback(
    async (email: string, password: string) => {
      const response = await api.post<LoginResponse>('/auth/login', { email, password })
      writeToken(response.data.token)
      applySession(response.data.user, response.data.team)
    },
    [applySession],
  )

  // El registro devuelve token igual que el login: la tripulacion entra
  // directo a la app, sin pasar por la pantalla de login.
  const register = useCallback(
    async (teamName: string, email: string, password: string) => {
      const response = await api.post<LoginResponse>('/auth/register', {
        teamName,
        email,
        password,
      })
      writeToken(response.data.token)
      applySession(response.data.user, response.data.team)
    },
    [applySession],
  )

  const value = useMemo<AuthValue>(
    () => ({ status, user, team, login, register, logout: dropSession }),
    [status, user, team, login, register, dropSession],
  )

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export function useAuth(): AuthValue {
  const value = useContext(AuthContext)
  if (!value) {
    throw new Error('useAuth debe usarse dentro de <AuthProvider>.')
  }
  return value
}
