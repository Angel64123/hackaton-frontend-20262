import { Navigate, Outlet, useLocation } from 'react-router-dom'
import { useAuth } from './AuthContext'
import { SplashScreen } from '../components/States'

/**
 * Puerta de las rutas privadas.
 *
 * - `checking`: splash, nunca el login (CP1: "sin mostrar el login mientras se verifica").
 * - `anonymous`: al login, guardando en el state la ruta completa que se queria
 *   abrir para volver exactamente ahi despues de iniciar sesion.
 */
export function RequireAuth() {
  const { status } = useAuth()
  const location = useLocation()

  if (status === 'checking') {
    return <SplashScreen message="Comprobando tu sesión…" />
  }

  if (status === 'anonymous') {
    return <Navigate to="/login" replace state={{ from: location }} />
  }

  return <Outlet />
}

/** Lo que RequireAuth guarda al redirigir al login. */
export interface FromState {
  from?: {
    pathname: string
    search?: string
    hash?: string
  }
}

/**
 * Reconstruye la ruta a la que el usuario queria entrar, con su query string
 * y su hash. Mantener el search importa: las URLs del CP2 llevan ahi los
 * filtros, la pagina y el orden.
 */
export function resolveRedirectTarget(state: unknown): string {
  const typed = state as FromState | null
  const from = typed?.from
  if (!from || typeof from.pathname !== 'string') return '/'
  if (from.pathname === '/login' || from.pathname === '/register') return '/'
  return `${from.pathname}${from.search ?? ''}${from.hash ?? ''}`
}
