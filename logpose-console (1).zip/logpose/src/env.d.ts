/// <reference types="vite/client" />

interface ImportMetaEnv {
  /** URL base de la API, por ejemplo https://host/api/v1 */
  readonly VITE_API_BASE_URL: string
}

interface ImportMeta {
  readonly env: ImportMetaEnv
}
