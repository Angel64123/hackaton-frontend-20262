import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react'
import type { ReactNode } from 'react'
import { api, parseApiError } from '../lib/api'
import type { LogPose } from '../lib/types'

interface LogPoseValue {
  logPose: LogPose | null
  loading: boolean
  error: string | null
  /** Vuelve a consultar /log-pose: se usa tras aprobar la inspeccion del CP3. */
  refresh: () => void
}

const LogPoseContext = createContext<LogPoseValue | null>(null)

/**
 * Estado del Log Pose compartido por la app: el dashboard lo muestra y la barra
 * de navegacion marca con candado los tramos del Grand Line mientras siga LOCKED.
 */
export function LogPoseProvider({ children }: { children: ReactNode }) {
  const [logPose, setLogPose] = useState<LogPose | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [reloadToken, setReloadToken] = useState(0)

  const refresh = useCallback(() => {
    setReloadToken((value) => value + 1)
  }, [])

  useEffect(() => {
    let cancelled = false
    setLoading(true)
    setError(null)

    api
      .get<LogPose>('/log-pose')
      .then((response) => {
        if (cancelled) return
        setLogPose(response.data)
      })
      .catch((err: unknown) => {
        if (cancelled) return
        setError(parseApiError(err).message)
      })
      .finally(() => {
        if (cancelled) return
        setLoading(false)
      })

    return () => {
      cancelled = true
    }
  }, [reloadToken])

  const value = useMemo<LogPoseValue>(
    () => ({ logPose, loading, error, refresh }),
    [logPose, loading, error, refresh],
  )

  return <LogPoseContext.Provider value={value}>{children}</LogPoseContext.Provider>
}

export function useLogPose(): LogPoseValue {
  const value = useContext(LogPoseContext)
  if (!value) {
    throw new Error('useLogPose debe usarse dentro de <LogPoseProvider>.')
  }
  return value
}
