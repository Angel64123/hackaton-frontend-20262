import { useLocation, useNavigate, useParams } from 'react-router-dom'
import { useApiResource } from '../hooks/useApiResource'
import {
  CREW_ROLE_LABEL,
  FRUIT_FILTER_LABEL,
  WANTED_STATUS_CLASS,
  WANTED_STATUS_LABEL,
  formatBerries,
  formatDateTime,
} from '../lib/format'
import type { WantedDetail } from '../lib/types'
import { Badge, ErrorState, LoadingState } from '../components/States'

interface DetailState {
  /** Query string del listado del que venimos, para volver con los filtros puestos. */
  listSearch?: string
}

export function WantedDetailPage() {
  const { id } = useParams<{ id: string }>()
  const location = useLocation()
  const navigate = useNavigate()

  const state = location.state as DetailState | null
  const listUrl = `/wanted${state?.listSearch ?? ''}`
  // location.key es 'default' solo si esta es la primera entrada del historial
  // (se abrio el detalle directo). En ese caso no hay "atras" al que volver.
  const cameFromApp = location.key !== 'default'

  const { data, loading, error, reload } = useApiResource<WantedDetail>(
    id ? `/wanted/${id}` : null,
  )

  function goBack() {
    if (cameFromApp) {
      // Volver por el historial devuelve el listado tal como se dejo:
      // filtros, pagina, orden y posicion de scroll.
      navigate(-1)
    } else {
      navigate(listUrl, { replace: true })
    }
  }

  return (
    <div className="space-y-6">
      <button
        type="button"
        onClick={goBack}
        className="rounded-lg border border-white/10 px-3 py-1.5 text-sm text-slate-300 transition hover:bg-white/5 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-amber-300"
      >
        ← Volver al listado
      </button>

      {loading && !data && <LoadingState label="Cargando el cartel…" />}

      {error && !data && (
        <ErrorState
          error={error}
          onRetry={error.status === 404 ? undefined : reload}
          title={error.status === 404 ? 'Este cartel no existe' : 'No pudimos cargar el cartel'}
        />
      )}

      {data && (
        <article className="space-y-6">
          <header className="rounded-2xl border border-white/10 bg-white/[0.02] p-6">
            <div className="flex flex-wrap items-start justify-between gap-4">
              <div>
                <p className="text-xs font-semibold tracking-[0.2em] text-amber-300/80 uppercase">
                  Se busca
                </p>
                <h1 className="mt-1 text-3xl font-semibold tracking-tight text-slate-50">
                  {data.name}
                </h1>
                <p className="mt-1 text-lg text-slate-400">«{data.epithet}»</p>
              </div>

              <div className="text-right">
                <p className="font-mono text-2xl text-amber-300">
                  {formatBerries(data.bounty)}
                  <span className="ml-1 text-sm text-amber-300/70">berries</span>
                </p>
                <div className="mt-2 flex justify-end">
                  <Badge className={WANTED_STATUS_CLASS[data.status]}>
                    {WANTED_STATUS_LABEL[data.status]}
                  </Badge>
                </div>
              </div>
            </div>

            <p className="mt-5 max-w-prose text-sm leading-relaxed text-slate-300">{data.bio}</p>
          </header>

          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            <Fact label="Tripulación" value={data.crew.name} />
            <Fact label="Puesto" value={CREW_ROLE_LABEL[data.role]} />
            <Fact
              label="Fruta del diablo"
              value={
                data.devilFruit
                  ? `${data.devilFruit.name} · ${FRUIT_FILTER_LABEL[data.devilFruit.type]}`
                  : 'No comió ninguna'
              }
            />
            <Fact
              label="Nivel de amenaza"
              value={`${'★'.repeat(data.threatLevel)}${'☆'.repeat(5 - data.threatLevel)} (${data.threatLevel}/5)`}
            />
            <Fact label="Edad" value={`${data.age} años`} />
            <Fact label="Altura" value={`${data.heightCm} cm`} />
            <Fact label="Última isla" value={data.lastSeen.island} />
            <Fact label="Visto por última vez" value={formatDateTime(data.lastSeen.seenAt)} />
            <Fact label="Cartel actualizado" value={formatDateTime(data.updatedAt)} />
          </div>

          {data.bountyHistory.length > 0 && (
            <section
              aria-labelledby="bounty-history"
              className="rounded-2xl border border-white/10 bg-white/[0.02] p-6"
            >
              <h2
                id="bounty-history"
                className="text-sm font-semibold tracking-wide text-slate-300 uppercase"
              >
                Historial de recompensas
              </h2>
              <ol className="mt-4 space-y-3">
                {data.bountyHistory.map((entry) => (
                  <li
                    key={`${entry.issuedAt}-${entry.amount}`}
                    className="flex items-center justify-between gap-4 border-b border-white/5 pb-2 last:border-0 last:pb-0"
                  >
                    <span className="text-sm text-slate-400">{formatDateTime(entry.issuedAt)}</span>
                    <span className="font-mono text-sm text-amber-300">
                      {formatBerries(entry.amount)}
                    </span>
                  </li>
                ))}
              </ol>
            </section>
          )}
        </article>
      )}
    </div>
  )
}

function Fact({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl border border-white/10 bg-white/[0.02] p-4">
      <p className="text-xs font-semibold tracking-wide text-slate-400 uppercase">{label}</p>
      <p className="mt-1.5 text-slate-100">{value}</p>
    </div>
  )
}
