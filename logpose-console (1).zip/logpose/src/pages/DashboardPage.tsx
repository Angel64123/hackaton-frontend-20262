import { Link } from 'react-router-dom'
import { useApiResource } from '../hooks/useApiResource'
import { useAuth } from '../auth/AuthContext'
import { useLogPose } from '../logpose/LogPoseContext'
import {
  formatBerries,
  formatCompactBerries,
  formatDateTime,
  formatNumber,
  WANTED_STATUS_CLASS,
  WANTED_STATUS_LABEL,
  FRUIT_FILTER_LABEL,
} from '../lib/format'
import { Badge, EmptyState, ErrorState, LoadingState } from '../components/States'
import { FRUIT_FILTERS, WANTED_STATUSES } from '../lib/types'
import type { DashboardSummary } from '../lib/types'

export function DashboardPage() {
  const { team } = useAuth()
  const { logPose, loading: logPoseLoading, error: logPoseError, refresh } = useLogPose()
  const { data, loading, error, reload } = useApiResource<DashboardSummary>('/dashboard/summary')

  return (
    <div className="space-y-8">
      <header>
        <h1 className="text-2xl font-semibold tracking-tight text-slate-50">
          Rumbo de {team?.name ?? 'la tripulación'}
        </h1>
        <p className="mt-1 text-sm text-slate-400">
          Indicadores del workspace
          {data ? ` · generado ${formatDateTime(data.generatedAt)}` : ''}
        </p>
      </header>

      {/* Estado del Log Pose: decide si el Grand Line esta abierto. */}
      <section
        aria-labelledby="logpose-heading"
        className={`rounded-2xl border p-6 ${
          logPose?.grandLineUnlocked
            ? 'border-emerald-400/30 bg-emerald-400/5'
            : 'border-amber-400/30 bg-amber-400/5'
        }`}
      >
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <h2 id="logpose-heading" className="text-sm font-semibold tracking-wide text-slate-300 uppercase">
              Log Pose
            </h2>
            {logPoseLoading && <p className="mt-2 text-sm text-slate-400">Consultando…</p>}
            {logPoseError && !logPose && (
              <p className="mt-2 text-sm text-rose-200">{logPoseError}</p>
            )}
            {logPose && (
              <>
                <p className="mt-2 flex items-center gap-2 text-lg font-medium text-slate-50">
                  {logPose.grandLineUnlocked ? '🧭 Grand Line abierto' : '🔒 Grand Line cerrado'}
                  <Badge
                    className={
                      logPose.grandLineUnlocked
                        ? 'bg-emerald-500/15 text-emerald-200 ring-emerald-500/30'
                        : 'bg-amber-500/15 text-amber-200 ring-amber-500/30'
                    }
                  >
                    {logPose.status}
                  </Badge>
                </p>
                <p className="mt-1 max-w-prose text-sm text-slate-300">{logPose.message}</p>
                {logPose.unlockedAt && (
                  <p className="mt-1 text-xs text-slate-400">
                    Aprobado el {formatDateTime(logPose.unlockedAt)}
                  </p>
                )}
              </>
            )}
          </div>
          <button
            type="button"
            onClick={refresh}
            className="rounded-lg border border-white/10 px-3 py-1.5 text-sm text-slate-200 transition hover:bg-white/5 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-amber-300"
          >
            Volver a consultar
          </button>
        </div>
      </section>

      {loading && !data && <LoadingState label="Cargando indicadores…" rows={3} />}

      {error && !data && <ErrorState error={error} onRetry={reload} />}

      {data && (
        <>
          <section aria-label="Resumen de carteles" className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <StatCard label="Carteles" value={formatNumber(data.wanted.total)} />
            <StatCard
              label="Recompensa total"
              value={formatCompactBerries(data.wanted.totalBounty)}
              hint={`${formatBerries(data.wanted.totalBounty)} berries`}
            />
            <StatCard
              label="Recompensa promedio"
              value={formatCompactBerries(data.wanted.averageBounty)}
              hint={`${formatBerries(data.wanted.averageBounty)} berries`}
            />
            <StatCard label="Tripulaciones piratas" value={formatNumber(data.crews.total)} />
          </section>

          <div className="grid gap-6 lg:grid-cols-2">
            <section
              aria-labelledby="by-status"
              className="rounded-2xl border border-white/10 bg-white/[0.02] p-6"
            >
              <h2 id="by-status" className="text-sm font-semibold tracking-wide text-slate-300 uppercase">
                Por estado
              </h2>
              <ul className="mt-4 space-y-2">
                {WANTED_STATUSES.map((status) => (
                  <li key={status} className="flex items-center justify-between gap-3">
                    <Link
                      to={`/wanted?status=${status}`}
                      className="text-sm text-slate-200 underline-offset-4 hover:text-amber-200 hover:underline"
                    >
                      {WANTED_STATUS_LABEL[status]}
                    </Link>
                    <Badge className={WANTED_STATUS_CLASS[status]}>
                      {formatNumber(data.wanted.byStatus[status])}
                    </Badge>
                  </li>
                ))}
              </ul>
            </section>

            <section
              aria-labelledby="by-fruit"
              className="rounded-2xl border border-white/10 bg-white/[0.02] p-6"
            >
              <h2 id="by-fruit" className="text-sm font-semibold tracking-wide text-slate-300 uppercase">
                Por fruta del diablo
              </h2>
              <ul className="mt-4 space-y-2">
                {FRUIT_FILTERS.map((fruit) => (
                  <li key={fruit} className="flex items-center justify-between gap-3">
                    <Link
                      to={`/wanted?fruit=${fruit}`}
                      className="text-sm text-slate-200 underline-offset-4 hover:text-amber-200 hover:underline"
                    >
                      {FRUIT_FILTER_LABEL[fruit]}
                    </Link>
                    <span className="font-mono text-sm text-slate-300">
                      {formatNumber(data.wanted.byFruit[fruit])}
                    </span>
                  </li>
                ))}
              </ul>
            </section>
          </div>

          {data.crews.mostWanted && (
            <section
              aria-labelledby="most-wanted-crew"
              className="rounded-2xl border border-white/10 bg-white/[0.02] p-6"
            >
              <h2
                id="most-wanted-crew"
                className="text-sm font-semibold tracking-wide text-slate-300 uppercase"
              >
                Tripulación más buscada
              </h2>
              <div className="mt-4 flex flex-wrap items-center gap-4">
                <span
                  aria-hidden="true"
                  className="h-10 w-10 shrink-0 rounded-full ring-2 ring-white/20"
                  style={{ backgroundColor: data.crews.mostWanted.jollyRogerColor }}
                />
                <div className="min-w-0">
                  <p className="font-medium text-slate-50">{data.crews.mostWanted.name}</p>
                  <p className="text-sm text-slate-400">
                    Barco {data.crews.mostWanted.shipName} ·{' '}
                    {formatNumber(data.crews.mostWanted.memberCount)} miembros
                  </p>
                </div>
                <p className="ml-auto font-mono text-amber-300">
                  {formatCompactBerries(data.crews.mostWanted.totalBounty)}
                </p>
              </div>
            </section>
          )}

          <section aria-labelledby="top-bounties">
            <div className="mb-4 flex items-center justify-between gap-4">
              <h2
                id="top-bounties"
                className="text-sm font-semibold tracking-wide text-slate-300 uppercase"
              >
                Mayores recompensas
              </h2>
              <Link
                to="/wanted"
                className="text-sm font-medium text-amber-300 hover:text-amber-200"
              >
                Ver todos los carteles →
              </Link>
            </div>

            {data.topBounties.length === 0 ? (
              <EmptyState
                title="Todavía no hay carteles en este workspace"
                hint="Cuando la Guild publique carteles aparecerán aquí."
              />
            ) : (
              <ul className="grid gap-3 sm:grid-cols-2">
                {data.topBounties.map((wanted) => (
                  <li key={wanted.id}>
                    <Link
                      to={`/wanted/${wanted.id}`}
                      className="flex items-center justify-between gap-4 rounded-xl border border-white/10 bg-white/[0.02] p-4 transition hover:border-amber-300/40 hover:bg-white/[0.04] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-amber-300"
                    >
                      <div className="min-w-0">
                        <p className="truncate font-medium text-slate-50">{wanted.name}</p>
                        <p className="truncate text-sm text-slate-400">«{wanted.epithet}»</p>
                      </div>
                      <div className="shrink-0 text-right">
                        <p className="font-mono text-amber-300">
                          {formatCompactBerries(wanted.bounty)}
                        </p>
                        <Badge className={WANTED_STATUS_CLASS[wanted.status]}>
                          {WANTED_STATUS_LABEL[wanted.status]}
                        </Badge>
                      </div>
                    </Link>
                  </li>
                ))}
              </ul>
            )}
          </section>
        </>
      )}
    </div>
  )
}

function StatCard({ label, value, hint }: { label: string; value: string; hint?: string }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/[0.02] p-5">
      <p className="text-xs font-semibold tracking-wide text-slate-400 uppercase">{label}</p>
      <p className="mt-2 text-2xl font-semibold text-slate-50">{value}</p>
      {hint && <p className="mt-1 text-xs text-slate-500">{hint}</p>}
    </div>
  )
}
