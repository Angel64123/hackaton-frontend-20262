import { Link, useLocation } from 'react-router-dom'
import { useAuth } from '../auth/AuthContext'
import { Compass } from '../components/States'

/**
 * 404 de la app (CP1). Vive fuera de las rutas privadas para que una direccion
 * inexistente no mande a nadie al login: el problema es la URL, no la sesion.
 */
export function NotFoundPage() {
  const { status } = useAuth()
  const location = useLocation()

  return (
    <div className="grid min-h-screen place-items-center px-4 py-10 text-center">
      <div className="max-w-md">
        <Compass className="mx-auto h-12 w-12 text-amber-300" />
        <p className="mt-6 font-mono text-5xl font-semibold text-amber-300">404</p>
        <h1 className="mt-3 text-xl font-semibold text-slate-50">Esta isla no está en el mapa</h1>
        <p className="mt-2 text-sm text-slate-400">
          No existe ninguna ruta en{' '}
          <code className="rounded bg-white/5 px-1.5 py-0.5 font-mono text-slate-300">
            {location.pathname}
          </code>
          .
        </p>

        <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
          {status === 'authenticated' ? (
            <>
              <Link
                to="/"
                className="rounded-lg bg-amber-400 px-4 py-2 text-sm font-medium text-slate-950 transition hover:bg-amber-300"
              >
                Ir al dashboard
              </Link>
              <Link
                to="/wanted"
                className="rounded-lg border border-white/10 px-4 py-2 text-sm text-slate-200 transition hover:bg-white/5"
              >
                Ver carteles
              </Link>
            </>
          ) : (
            <Link
              to="/login"
              className="rounded-lg bg-amber-400 px-4 py-2 text-sm font-medium text-slate-950 transition hover:bg-amber-300"
            >
              Ir al login
            </Link>
          )}
        </div>
      </div>
    </div>
  )
}
