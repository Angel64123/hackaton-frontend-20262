import { useState } from 'react'
import type { FormEvent } from 'react'
import { Link, Navigate, useLocation } from 'react-router-dom'
import { useAuth } from '../auth/AuthContext'
import { resolveRedirectTarget } from '../auth/RequireAuth'
import { parseApiError } from '../lib/api'
import { Compass, FieldError, Spinner, SplashScreen } from '../components/States'

/* Limites tomados del contrato (RegisterRequest). */
const TEAM_NAME_MIN = 3
const TEAM_NAME_MAX = 40
const PASSWORD_MIN = 8
const PASSWORD_MAX = 72
const EMAIL_MAX = 120

export function RegisterPage() {
  const { status, register } = useAuth()
  const location = useLocation()
  const target = resolveRedirectTarget(location.state)

  const [teamName, setTeamName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [submitting, setSubmitting] = useState(false)
  const [formError, setFormError] = useState<string | null>(null)
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({})

  if (status === 'checking') {
    return <SplashScreen message="Comprobando tu sesión…" />
  }

  // El registro deja la sesion iniciada, asi que al terminar esta misma
  // condicion entra a la app sin pasar por el login.
  if (status === 'authenticated') {
    return <Navigate to={target} replace />
  }

  function validate(): Record<string, string> {
    const errors: Record<string, string> = {}
    const name = teamName.trim()

    if (name.length < TEAM_NAME_MIN || name.length > TEAM_NAME_MAX) {
      errors.teamName = `El nombre debe tener entre ${TEAM_NAME_MIN} y ${TEAM_NAME_MAX} caracteres.`
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      errors.email = 'Escribe un email válido.'
    } else if (email.trim().length > EMAIL_MAX) {
      errors.email = `El email no puede pasar de ${EMAIL_MAX} caracteres.`
    }
    if (password.length < PASSWORD_MIN || password.length > PASSWORD_MAX) {
      errors.password = `La contraseña debe tener entre ${PASSWORD_MIN} y ${PASSWORD_MAX} caracteres.`
    }

    return errors
  }

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setFormError(null)

    const localErrors = validate()
    if (Object.keys(localErrors).length > 0) {
      setFieldErrors(localErrors)
      return
    }
    setFieldErrors({})

    setSubmitting(true)
    try {
      await register(teamName.trim(), email.trim(), password)
    } catch (error) {
      const parsed = parseApiError(error)

      // El contrato trae details[{field, message}] en los 400, y en los 409
      // dice con el `code` cual de los dos campos esta repetido. En los dos
      // casos el mensaje termina junto a su input.
      const nextErrors: Record<string, string> = { ...parsed.fieldErrors }

      if (parsed.code === 'EMAIL_ALREADY_REGISTERED') {
        nextErrors.email = 'Ese email ya tiene una tripulación registrada.'
      } else if (parsed.code === 'TEAM_NAME_TAKEN') {
        nextErrors.teamName = 'Ese nombre de tripulación ya está tomado.'
      } else if (parsed.code === 'REGISTRATION_CLOSED') {
        setFormError('El cupo de tripulaciones está lleno. Avisa a un TA.')
      } else if (Object.keys(nextErrors).length === 0) {
        setFormError(parsed.message)
      }

      setFieldErrors(nextErrors)
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div className="grid min-h-screen place-items-center px-4 py-10">
      <div className="w-full max-w-md">
        <div className="mb-8 flex flex-col items-center gap-3 text-center">
          <Compass className="h-11 w-11 text-amber-300" />
          <h1 className="text-2xl font-semibold tracking-tight text-slate-50">
            Registra tu tripulación
          </h1>
          <p className="text-sm text-slate-400">
            El servidor te asigna el código de equipo al crear la cuenta
          </p>
        </div>

        <form
          onSubmit={handleSubmit}
          noValidate
          className="space-y-5 rounded-2xl border border-white/10 bg-white/[0.03] p-6 sm:p-8"
        >
          {formError && (
            <p
              className="rounded-lg border border-rose-500/30 bg-rose-500/10 px-4 py-3 text-sm text-rose-100"
              role="alert"
            >
              {formError}
            </p>
          )}

          <div>
            <label htmlFor="teamName" className="block text-sm font-medium text-slate-200">
              Nombre de la tripulación
            </label>
            <input
              id="teamName"
              name="teamName"
              type="text"
              autoComplete="organization"
              value={teamName}
              onChange={(event) => setTeamName(event.target.value)}
              aria-invalid={Boolean(fieldErrors.teamName)}
              className="mt-1.5 w-full rounded-lg border border-white/10 bg-slate-950/60 px-3 py-2 text-slate-100 outline-none transition focus:border-amber-300/60 focus:ring-2 focus:ring-amber-300/20"
            />
            <FieldError message={fieldErrors.teamName} />
          </div>

          <div>
            <label htmlFor="email" className="block text-sm font-medium text-slate-200">
              Email
            </label>
            <input
              id="email"
              name="email"
              type="email"
              autoComplete="email"
              value={email}
              onChange={(event) => setEmail(event.target.value)}
              aria-invalid={Boolean(fieldErrors.email)}
              className="mt-1.5 w-full rounded-lg border border-white/10 bg-slate-950/60 px-3 py-2 text-slate-100 outline-none transition focus:border-amber-300/60 focus:ring-2 focus:ring-amber-300/20"
            />
            <FieldError message={fieldErrors.email} />
            <p className="mt-1.5 text-xs text-slate-500">
              Los tres integrantes inician sesión con este email.
            </p>
          </div>

          <div>
            <label htmlFor="password" className="block text-sm font-medium text-slate-200">
              Contraseña
            </label>
            <input
              id="password"
              name="password"
              type="password"
              autoComplete="new-password"
              value={password}
              onChange={(event) => setPassword(event.target.value)}
              aria-invalid={Boolean(fieldErrors.password)}
              className="mt-1.5 w-full rounded-lg border border-white/10 bg-slate-950/60 px-3 py-2 text-slate-100 outline-none transition focus:border-amber-300/60 focus:ring-2 focus:ring-amber-300/20"
            />
            <FieldError message={fieldErrors.password} />
            <p className="mt-1.5 text-xs text-slate-500">
              De {PASSWORD_MIN} a {PASSWORD_MAX} caracteres.
            </p>
          </div>

          <button
            type="submit"
            disabled={submitting}
            className="flex w-full items-center justify-center gap-2 rounded-lg bg-amber-400 px-4 py-2.5 font-medium text-slate-950 transition hover:bg-amber-300 disabled:cursor-not-allowed disabled:opacity-60 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-amber-300"
          >
            {submitting && <Spinner className="h-4 w-4" />}
            {submitting ? 'Registrando…' : 'Crear tripulación y entrar'}
          </button>

          <p className="text-center text-sm text-slate-400">
            ¿Ya tienen cuenta?{' '}
            <Link
              to="/login"
              state={location.state}
              className="font-medium text-amber-300 hover:text-amber-200"
            >
              Inicia sesión
            </Link>
          </p>
        </form>
      </div>
    </div>
  )
}
