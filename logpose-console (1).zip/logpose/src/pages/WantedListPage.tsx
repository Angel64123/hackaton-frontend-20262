import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import { api, isAbort, parseApiError } from '../lib/api'
import type { ParsedApiError } from '../lib/api'
import { useApiResource } from '../hooks/useApiResource'
import { useDebouncedValue } from '../hooks/useDebouncedValue'
import {
  hasActiveFilters,
  parseWantedQuery,
  toRequestParams,
  wantedQueryKey,
  wantedSearchString,
} from '../lib/wantedQuery'
import {
  CREW_ROLE_LABEL,
  FRUIT_FILTER_LABEL,
  WANTED_SORT_LABEL,
  WANTED_STATUS_CLASS,
  WANTED_STATUS_LABEL,
  formatCompactBerries,
  formatDate,
  formatNumber,
} from '../lib/format'
import { FRUIT_FILTERS, MAX_QUERY_LENGTH, PAGE_SIZES, WANTED_SORTS, WANTED_STATUSES } from '../lib/types'
import type { Crew, WantedPage, WantedSummary } from '../lib/types'
import { Badge, EmptyState, ErrorState, LoadingState, Spinner } from '../components/States'

/** Claves que la vista escribe en la URL. */
type ParamKey = 'page' | 'size' | 'status' | 'crewId' | 'fruit' | 'q' | 'sort'
type ParamPatch = Partial<Record<ParamKey, string | null>>

export function WantedListPage() {
  const [searchParams, setSearchParams] = useSearchParams()
  const query = useMemo(() => parseWantedQuery(searchParams), [searchParams])
  const queryKey = wantedQueryKey(query)

  const [data, setData] = useState<WantedPage | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<ParsedApiError | null>(null)
  const [reloadToken, setReloadToken] = useState(0)

  /**
   * Contador de peticiones. Cada request se queda con su numero; al volver,
   * solo escribe en el estado si sigue siendo la ultima.
   *
   * Es la segunda defensa contra respuestas viejas: el AbortController corta
   * la que ya no interesa, pero una respuesta que venia en camino puede
   * resolverse igual, y entonces este contador la descarta.
   */
  const requestIdRef = useRef(0)

  const crews = useApiResource<Crew[]>('/crews')

  /** Escribe en la URL. Un valor null borra el parametro. */
  const updateParams = useCallback(
    (patch: ParamPatch, options?: { replace?: boolean }) => {
      setSearchParams(
        (previous) => {
          const next = new URLSearchParams(previous)
          for (const [key, value] of Object.entries(patch)) {
            if (value === null || value === '') next.delete(key)
            else next.set(key, value)
          }
          return next
        },
        { replace: options?.replace ?? false },
      )
    },
    [setSearchParams],
  )

  /**
   * Cambiar un filtro, el orden o el tamano borra `page`, que equivale a
   * volver a la pagina 0. Sin esto, filtrar desde la pagina 5 dejaria al
   * usuario en una pagina que con el filtro nuevo quizas no existe.
   */
  const setFilter = useCallback(
    (key: ParamKey, value: string | null) => {
      updateParams({ [key]: value, page: null })
    },
    [updateParams],
  )

  /* ---------- busqueda con debounce ---------- */

  const [searchText, setSearchText] = useState(query.q)
  const debouncedSearch = useDebouncedValue(searchText, 350)
  // Ultimo texto que ya esta reflejado en la URL. Evita que los dos efectos de
  // abajo se peleen (uno escribe la URL, el otro lee la URL).
  const committedSearchRef = useRef(query.q)

  // Lo escrito llega a la URL solo cuando el usuario deja de teclear.
  // `replace` evita llenar el historial con una entrada por pulsacion.
  useEffect(() => {
    if (debouncedSearch === committedSearchRef.current) return
    committedSearchRef.current = debouncedSearch
    updateParams({ q: debouncedSearch.trim() || null, page: null }, { replace: true })
  }, [debouncedSearch, updateParams])

  // Si la URL cambia por fuera (atras, adelante, un enlace, limpiar filtros),
  // el input adopta ese valor.
  useEffect(() => {
    if (query.q !== committedSearchRef.current) {
      committedSearchRef.current = query.q
      setSearchText(query.q)
    }
  }, [query.q])

  /* ---------- carga de la pagina ---------- */

  useEffect(() => {
    const requestId = ++requestIdRef.current
    const controller = new AbortController()

    setLoading(true)
    setError(null)

    api
      .get<WantedPage>('/wanted', {
        params: toRequestParams(parseWantedQuery(new URLSearchParams(searchParams))),
        signal: controller.signal,
      })
      .then((response) => {
        if (requestId !== requestIdRef.current) return
        setData(response.data)
      })
      .catch((err: unknown) => {
        if (requestId !== requestIdRef.current || isAbort(err)) return
        setError(parseApiError(err))
      })
      .finally(() => {
        if (requestId !== requestIdRef.current) return
        setLoading(false)
      })

    return () => {
      controller.abort()
    }
    // queryKey resume los parametros que importan: cambia solo si cambio algo
    // que afecta la request.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [queryKey, reloadToken])

  /**
   * Si la pagina pedida ya no existe (por ejemplo, se filtro y quedan 2
   * paginas pero la URL decia page=6), llevamos al usuario a la ultima valida.
   * El contrato responde 200 con content vacio y los totales correctos, asi
   * que podemos corregir sin adivinar.
   */
  useEffect(() => {
    if (!data) return
    if (query.page > 0 && query.page >= data.totalPages) {
      const lastPage = Math.max(0, data.totalPages - 1)
      updateParams({ page: lastPage > 0 ? String(lastPage) : null }, { replace: true })
    }
  }, [data, query.page, updateParams])

  const retry = useCallback(() => {
    setReloadToken((value) => value + 1)
  }, [])

  const clearFilters = useCallback(() => {
    setSearchParams(new URLSearchParams(), { replace: false })
  }, [setSearchParams])

  const listSearch = wantedSearchString(query)
  const items = data?.content ?? []
  const showSkeleton = loading && !data
  const filtersActive = hasActiveFilters(query)

  return (
    <div className="space-y-6">
      <header className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight text-slate-50">
            Carteles de «Se Busca»
          </h1>
          <p className="mt-1 text-sm text-slate-400">
            {data
              ? `${formatNumber(data.totalElements)} carteles · página ${data.page + 1} de ${Math.max(1, data.totalPages)}`
              : 'Cargando el archivo de la Guild…'}
          </p>
        </div>
        {loading && data && (
          <p className="flex items-center gap-2 text-sm text-slate-400" role="status">
            <Spinner className="h-4 w-4 text-amber-300" />
            Actualizando…
          </p>
        )}
      </header>

      {/* ---------- filtros ---------- */}
      <section
        aria-label="Filtros"
        className="grid gap-4 rounded-2xl border border-white/10 bg-white/[0.02] p-4 sm:p-5 lg:grid-cols-12"
      >
        <div className="lg:col-span-4">
          <label htmlFor="q" className="block text-xs font-semibold tracking-wide text-slate-400 uppercase">
            Buscar por nombre o epíteto
          </label>
          <input
            id="q"
            type="search"
            value={searchText}
            maxLength={MAX_QUERY_LENGTH}
            onChange={(event) => setSearchText(event.target.value)}
            placeholder="Akane, Ancla Roja…"
            className="mt-1.5 w-full rounded-lg border border-white/10 bg-slate-950/60 px-3 py-2 text-sm text-slate-100 outline-none transition focus:border-amber-300/60 focus:ring-2 focus:ring-amber-300/20"
          />
        </div>

        <div className="lg:col-span-2">
          <label htmlFor="status" className="block text-xs font-semibold tracking-wide text-slate-400 uppercase">
            Estado
          </label>
          <select
            id="status"
            value={query.status ?? ''}
            onChange={(event) => setFilter('status', event.target.value || null)}
            className="mt-1.5 w-full rounded-lg border border-white/10 bg-slate-950/60 px-3 py-2 text-sm text-slate-100 outline-none transition focus:border-amber-300/60"
          >
            <option value="">Todos</option>
            {WANTED_STATUSES.map((status) => (
              <option key={status} value={status}>
                {WANTED_STATUS_LABEL[status]}
              </option>
            ))}
          </select>
        </div>

        <div className="lg:col-span-3">
          <label htmlFor="crewId" className="block text-xs font-semibold tracking-wide text-slate-400 uppercase">
            Tripulación
          </label>
          <select
            id="crewId"
            value={query.crewId ?? ''}
            onChange={(event) => setFilter('crewId', event.target.value || null)}
            className="mt-1.5 w-full rounded-lg border border-white/10 bg-slate-950/60 px-3 py-2 text-sm text-slate-100 outline-none transition focus:border-amber-300/60"
          >
            <option value="">Todas</option>
            {(crews.data ?? []).map((crew) => (
              <option key={crew.id} value={crew.id}>
                {crew.name}
              </option>
            ))}
          </select>
        </div>

        <div className="lg:col-span-3">
          <label htmlFor="fruit" className="block text-xs font-semibold tracking-wide text-slate-400 uppercase">
            Fruta del diablo
          </label>
          <select
            id="fruit"
            value={query.fruit ?? ''}
            onChange={(event) => setFilter('fruit', event.target.value || null)}
            className="mt-1.5 w-full rounded-lg border border-white/10 bg-slate-950/60 px-3 py-2 text-sm text-slate-100 outline-none transition focus:border-amber-300/60"
          >
            <option value="">Todas</option>
            {FRUIT_FILTERS.map((fruit) => (
              <option key={fruit} value={fruit}>
                {FRUIT_FILTER_LABEL[fruit]}
              </option>
            ))}
          </select>
        </div>

        <div className="lg:col-span-4">
          <label htmlFor="sort" className="block text-xs font-semibold tracking-wide text-slate-400 uppercase">
            Ordenar por
          </label>
          <select
            id="sort"
            value={query.sort}
            onChange={(event) => setFilter('sort', event.target.value)}
            className="mt-1.5 w-full rounded-lg border border-white/10 bg-slate-950/60 px-3 py-2 text-sm text-slate-100 outline-none transition focus:border-amber-300/60"
          >
            {WANTED_SORTS.map((sort) => (
              <option key={sort} value={sort}>
                {WANTED_SORT_LABEL[sort]}
              </option>
            ))}
          </select>
        </div>

        <div className="lg:col-span-2">
          <label htmlFor="size" className="block text-xs font-semibold tracking-wide text-slate-400 uppercase">
            Por página
          </label>
          <select
            id="size"
            value={query.size}
            onChange={(event) => setFilter('size', event.target.value)}
            className="mt-1.5 w-full rounded-lg border border-white/10 bg-slate-950/60 px-3 py-2 text-sm text-slate-100 outline-none transition focus:border-amber-300/60"
          >
            {PAGE_SIZES.map((size) => (
              <option key={size} value={size}>
                {size}
              </option>
            ))}
          </select>
        </div>

        {filtersActive && (
          <div className="flex items-end lg:col-span-6">
            <button
              type="button"
              onClick={clearFilters}
              className="rounded-lg border border-white/10 px-3 py-2 text-sm text-slate-300 transition hover:bg-white/5 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-amber-300"
            >
              Limpiar filtros
            </button>
          </div>
        )}
      </section>

      {/*
        Alto minimo reservado: el bloque de resultados no cambia de tamano al
        pasar de cargando a datos, a error o a vacio. El layout no salta.
      */}
      <section aria-label="Resultados" aria-busy={loading} className="min-h-[560px]">
        {showSkeleton && <LoadingState label="Cargando carteles…" rows={query.size > 20 ? 6 : 4} />}

        {error && !data && <ErrorState error={error} onRetry={retry} />}

        {error && data && (
          <div className="mb-4">
            <ErrorState
              error={error}
              onRetry={retry}
              title="No pudimos actualizar la lista"
            />
          </div>
        )}

        {!showSkeleton && !error && items.length === 0 && (
          <EmptyState
            title="Ningún cartel coincide con esta búsqueda"
            hint={
              filtersActive
                ? 'Prueba quitando algún filtro o cambiando el texto de búsqueda.'
                : 'Este workspace todavía no tiene carteles publicados.'
            }
          />
        )}

        {items.length > 0 && (
          <ul className={`space-y-3 transition-opacity ${loading ? 'opacity-60' : 'opacity-100'}`}>
            {items.map((wanted) => (
              <li key={wanted.id}>
                <WantedRow wanted={wanted} listSearch={listSearch} />
              </li>
            ))}
          </ul>
        )}
      </section>

      {/* ---------- paginacion ---------- */}
      {data && data.totalPages > 1 && (
        <nav aria-label="Paginación" className="flex flex-wrap items-center justify-center gap-3">
          <button
            type="button"
            disabled={query.page <= 0}
            onClick={() => {
              const previous = query.page - 1
              updateParams({ page: previous > 0 ? String(previous) : null })
            }}
            className="rounded-lg border border-white/10 px-4 py-2 text-sm text-slate-200 transition hover:bg-white/5 disabled:cursor-not-allowed disabled:opacity-40 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-amber-300"
          >
            ← Anterior
          </button>

          <p className="text-sm text-slate-400" aria-live="polite">
            Página <span className="font-medium text-slate-100">{data.page + 1}</span> de{' '}
            {data.totalPages}
          </p>

          <button
            type="button"
            disabled={query.page >= data.totalPages - 1}
            onClick={() => updateParams({ page: String(query.page + 1) })}
            className="rounded-lg border border-white/10 px-4 py-2 text-sm text-slate-200 transition hover:bg-white/5 disabled:cursor-not-allowed disabled:opacity-40 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-amber-300"
          >
            Siguiente →
          </button>
        </nav>
      )}
    </div>
  )
}

function WantedRow({ wanted, listSearch }: { wanted: WantedSummary; listSearch: string }) {
  return (
    <Link
      to={`/wanted/${wanted.id}`}
      // Guardamos la URL exacta del listado. Al volver desde el detalle, aunque
      // se haya abierto en una pestana nueva, se recupera con sus filtros.
      state={{ listSearch }}
      className="flex flex-wrap items-center gap-x-5 gap-y-3 rounded-xl border border-white/10 bg-white/[0.02] p-4 transition hover:border-amber-300/40 hover:bg-white/[0.04] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-amber-300"
    >
      <div className="min-w-[12rem] flex-1">
        <p className="font-medium text-slate-50">{wanted.name}</p>
        <p className="text-sm text-slate-400">«{wanted.epithet}»</p>
      </div>

      <div className="min-w-[10rem] text-sm text-slate-300">
        <p className="truncate">{wanted.crew.name}</p>
        <p className="text-xs text-slate-500">{CREW_ROLE_LABEL[wanted.role]}</p>
      </div>

      <div className="min-w-[8rem] text-sm text-slate-300">
        <p className="truncate">{wanted.lastSeenIsland}</p>
        <p className="text-xs text-slate-500">{formatDate(wanted.updatedAt)}</p>
      </div>

      <div className="flex min-w-[9rem] flex-col items-start gap-1.5">
        <Badge className={WANTED_STATUS_CLASS[wanted.status]}>
          {WANTED_STATUS_LABEL[wanted.status]}
        </Badge>
        <span className="text-xs text-slate-500">
          {wanted.devilFruit ? FRUIT_FILTER_LABEL[wanted.devilFruit.type] : 'Sin fruta'}
        </span>
      </div>

      <div className="ml-auto text-right">
        <p className="font-mono text-amber-300">{formatCompactBerries(wanted.bounty)}</p>
        <p className="text-xs text-slate-500" title={`Nivel de amenaza ${wanted.threatLevel} de 5`}>
          {'★'.repeat(wanted.threatLevel)}
          <span className="text-slate-700">{'★'.repeat(5 - wanted.threatLevel)}</span>
        </p>
      </div>
    </Link>
  )
}
