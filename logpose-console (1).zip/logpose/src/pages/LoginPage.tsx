import { useState } from 'react'
import type { FormEvent } from 'react'
import { Link, Navigate, useLocation } from 'react-router-dom'
import { useAuth } from '../auth/AuthContext'
import { resolveRedirectTarget } from '../auth/RequireAuth'
import { parseApiError } from '../lib/api'
import { Compass, FieldError, Spinner, SplashScreen } from '../components/States'

export function LoginPage() {
  const { status, login } = useAuth()
  const location = useLocation()
  const target = resolveRedirectTarget(location.state)

  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [submitting, setSubmitting] = useState(false)
  const [formError, setFormError] = useState<string | null>(null)
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({})

  // Mientras se verifica el token guardado no mostramos el formulario: si la
  // sesion sigue viva, el usuario nunca deberia ver esta pantalla.
  if (status === 'checking') {
    return <SplashScreen message="Comprobando tu sesión…" />
  }

  // Ya hay sesion: directo a donde queria ir (o al dashboard).
  if (status === 'authenticated') {
    return <Navigate to={target} replace />
  }

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setFormError(null)
    setFieldErrors({})

    const nextErrors: Record<string, string> = {}
    if (!email.trim()) nextErrors.email = 'Escribe el email de la tripulación.'
    if (!password) nextErrors.password = 'Escribe la contraseña.'
    if (Object.keys(nextErrors).length > 0) {
      setFieldErrors(nextErrors)
      return
    }

    setSubmitting(true)
    try {
      await login(email.trim(), password)
      // No navegamos a mano: al pasar a `authenticated` el <Navigate> de arriba
      // lleva al destino guardado.
    } catch (error) {
      const parsed = parseApiError(error)
      setFieldErrors(parsed.fieldErrors)

      if (parsed.code === 'INVALID_CREDENTIALS') {
        setFormError('Email o contraseña incorrectos.')
      } else if (parsed.code === 'RATE_LIMITED') {
        setFormError(
          `Demasiados intentos seguidos. Espera ${parsed.retryAfterSeconds ?? 30} s y vuelve a probar.`,
        )
      } else if (Object.keys(parsed.fieldErrors).length === 0) {
        setFormError(parsed.message)
      }
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div className="grid min-h-screen place-items-center px-4 py-10">
      <div className="w-full max-w-md">
        <div className="mb-8 flex flex-col items-center gap-3 text-center">
          <Compass className="h-11 w-11 text-amber-300" />
          <h1 className="text-2xl font-semibold tracking-tight text-slate-50">Log Pose Console</h1>
          <p className="text-sm text-slate-400">
            Guild de Cazarrecompensas · entra con la cuenta de tu tripulación
          </p>
        </div>

        <form
          onSubmit={handleSubmit}
          noValidate
          className="space-y-5 rounded-2xl border border-white/10 bg-white/[0.03] p-6 sm:p-8"
        >
          {formError && (
            <p
              className="rounded-lg border border-rose-500/30 bg-rose-500/10 px-4 py-3 text-sm text-rose-100"
              role="alert"
            >
              {formError}
            </p>
          )}

          <div>
            <label htmlFor="email" className="block text-sm font-medium text-slate-200">
              Email de la tripulación
            </label>
            <input
              id="email"
              name="email"
              type="email"
              autoComplete="email"
              value={email}
              onChange={(event) => setEmail(event.target.value)}
              aria-invalid={Boolean(fieldErrors.email)}
              className="mt-1.5 w-full rounded-lg border border-white/10 bg-slate-950/60 px-3 py-2 text-slate-100 outline-none transition focus:border-amber-300/60 focus:ring-2 focus:ring-amber-300/20"
            />
            <FieldError message={fieldErrors.email} />
          </div>

          <div>
            <label htmlFor="password" className="block text-sm font-medium text-slate-200">
              Contraseña
            </label>
            <input
              id="password"
              name="password"
              type="password"
              autoComplete="current-password"
              value={password}
              onChange={(event) => setPassword(event.target.value)}
              aria-invalid={Boolean(fieldErrors.password)}
              className="mt-1.5 w-full rounded-lg border border-white/10 bg-slate-950/60 px-3 py-2 text-slate-100 outline-none transition focus:border-amber-300/60 focus:ring-2 focus:ring-amber-300/20"
            />
            <FieldError message={fieldErrors.password} />
          </div>

          <button
            type="submit"
            disabled={submitting}
            className="flex w-full items-center justify-center gap-2 rounded-lg bg-amber-400 px-4 py-2.5 font-medium text-slate-950 transition hover:bg-amber-300 disabled:cursor-not-allowed disabled:opacity-60 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-amber-300"
          >
            {submitting && <Spinner className="h-4 w-4" />}
            {submitting ? 'Entrando…' : 'Zarpar'}
          </button>

          <p className="text-center text-sm text-slate-400">
            ¿Tripulación nueva?{' '}
            <Link
              to="/register"
              state={location.state}
              className="font-medium text-amber-300 hover:text-amber-200"
            >
              Regístrala aquí
            </Link>
          </p>
        </form>
      </div>
    </div>
  )
}
