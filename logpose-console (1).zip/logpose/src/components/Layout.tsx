import { NavLink, Outlet } from 'react-router-dom'
import { useAuth } from '../auth/AuthContext'
import { Compass } from './States'

const NAV_ITEMS = [
  { to: '/', label: 'Dashboard' },
  { to: '/wanted', label: 'Se Busca' },
]

export function Layout() {
  const { team, logout } = useAuth()

  return (
    <div className="min-h-screen bg-slate-950">
      <header className="sticky top-0 z-40 border-b border-white/10 bg-slate-950/85 backdrop-blur">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center gap-x-6 gap-y-3 px-4 py-3 sm:px-6">
          <div className="flex items-center gap-2.5">
            <Compass className="h-6 w-6 text-amber-300" />
            <span className="font-semibold tracking-tight text-slate-50">Log Pose Console</span>
          </div>

          <nav aria-label="Secciones" className="order-3 w-full sm:order-none sm:w-auto">
            <ul className="flex flex-wrap items-center gap-1">
              {NAV_ITEMS.map((item) => (
                <li key={item.to}>
                  <NavLink
                    to={item.to}
                    end={item.to === '/'}
                    className={({ isActive }) =>
                      `flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-sm transition ${
                        isActive
                          ? 'bg-amber-400/15 text-amber-100 ring-1 ring-amber-300/30'
                          : 'text-slate-300 hover:bg-white/5 hover:text-slate-100'
                      }`
                    }
                  >
                    {item.label}
                  </NavLink>
                </li>
              ))}
            </ul>
          </nav>

          <div className="ml-auto flex items-center gap-3">
            {team && (
              <div className="hidden text-right sm:block">
                <p className="text-sm leading-tight font-medium text-slate-100">{team.name}</p>
                <p className="font-mono text-xs leading-tight text-amber-300/80">{team.code}</p>
              </div>
            )}
            <button
              type="button"
              onClick={logout}
              className="rounded-lg border border-white/10 px-3 py-1.5 text-sm text-slate-300 transition hover:border-rose-400/40 hover:text-rose-200 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-amber-300"
            >
              Salir
            </button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
        <Outlet />
      </main>
    </div>
  )
}
