import { Route, Routes } from 'react-router-dom'
import { RequireAuth } from './auth/RequireAuth'
import { Layout } from './components/Layout'
import { LogPoseProvider } from './logpose/LogPoseContext'
import { LoginPage } from './pages/LoginPage'
import { RegisterPage } from './pages/RegisterPage'
import { DashboardPage } from './pages/DashboardPage'
import { WantedListPage } from './pages/WantedListPage'
import { WantedDetailPage } from './pages/WantedDetailPage'
import { NotFoundPage } from './pages/NotFoundPage'

/**
 * El estado del Log Pose se monta por encima de las rutas privadas, no dentro
 * de cada pagina: lo usan el dashboard y la barra de navegacion, y asi se
 * consulta una sola vez por sesion.
 */
function PrivateShell() {
  return (
    <LogPoseProvider>
      <Layout />
    </LogPoseProvider>
  )
}

export function App() {
  return (
    <Routes>
      <Route path="/login" element={<LoginPage />} />
      <Route path="/register" element={<RegisterPage />} />

      <Route element={<RequireAuth />}>
        <Route element={<PrivateShell />}>
          <Route index element={<DashboardPage />} />
          <Route path="wanted" element={<WantedListPage />} />
          <Route path="wanted/:id" element={<WantedDetailPage />} />
        </Route>
      </Route>

      {/* La 404 vive fuera de las rutas privadas: una direccion que no existe
          no es un problema de sesion, asi que no manda a nadie al login. */}
      <Route path="*" element={<NotFoundPage />} />
    </Routes>
  )
}
