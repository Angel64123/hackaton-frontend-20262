import {
  DEFAULT_SIZE,
  DEFAULT_SORT,
  FRUIT_FILTERS,
  MAX_QUERY_LENGTH,
  PAGE_SIZES,
  WANTED_SORTS,
  WANTED_STATUSES,
} from './types'
import type { FruitFilter, PageSize, WantedSort, WantedStatus } from './types'

/**
 * Estado de la vista de carteles. La URL es la unica fuente de verdad: no hay
 * una copia en useState que pueda quedar desincronizada. Por eso recargar,
 * compartir el enlace o usar atras y adelante muestran siempre lo mismo.
 */
export interface WantedQuery {
  page: number
  size: PageSize
  status: WantedStatus | null
  crewId: string | null
  fruit: FruitFilter | null
  q: string
  sort: WantedSort
}

/** Devuelve el valor solo si pertenece al contrato; si no, null. */
function pickEnum<T extends string>(raw: string | null, allowed: readonly T[]): T | null {
  if (!raw) return null
  return (allowed as readonly string[]).includes(raw) ? (raw as T) : null
}

/**
 * Lee la URL y la sanea.
 *
 * Un valor fuera del contrato (?size=7, ?sort=precio, ?page=-3) cae al default
 * en vez de viajar a la API: asi una URL manipulada no rompe la vista ni
 * provoca un 400. El contrato tambien dice que un parametro vacio equivale a
 * ausente, y `Number('')` es 0, que es justo el default de page.
 */
export function parseWantedQuery(params: URLSearchParams): WantedQuery {
  const rawPage = params.get('page')
  const parsedPage = rawPage === null ? 0 : Number(rawPage)
  const page = Number.isInteger(parsedPage) && parsedPage >= 0 ? parsedPage : 0

  const rawSize = params.get('size')
  const parsedSize = rawSize === null ? DEFAULT_SIZE : Number(rawSize)
  const size = (PAGE_SIZES as readonly number[]).includes(parsedSize)
    ? (parsedSize as PageSize)
    : DEFAULT_SIZE

  return {
    page,
    size,
    status: pickEnum(params.get('status'), WANTED_STATUSES),
    crewId: params.get('crewId')?.trim() || null,
    fruit: pickEnum(params.get('fruit'), FRUIT_FILTERS),
    q: (params.get('q') ?? '').slice(0, MAX_QUERY_LENGTH),
    sort: pickEnum(params.get('sort'), WANTED_SORTS) ?? DEFAULT_SORT,
  }
}

/**
 * Parametros que viajan a GET /wanted. Los filtros sin valor se omiten en vez
 * de mandarse vacios, y solo salen valores validos del contrato.
 */
export function toRequestParams(query: WantedQuery): Record<string, string | number> {
  const params: Record<string, string | number> = {
    page: query.page,
    size: query.size,
    sort: query.sort,
  }

  if (query.status) params.status = query.status
  if (query.crewId) params.crewId = query.crewId
  if (query.fruit) params.fruit = query.fruit

  const trimmed = query.q.trim()
  if (trimmed) params.q = trimmed

  return params
}

/** Clave estable de la consulta: dispara el efecto solo si algo cambio de verdad. */
export function wantedQueryKey(query: WantedQuery): string {
  return JSON.stringify(toRequestParams(query))
}

/** Query string canonica: omite lo que ya es default para dejar URLs limpias. */
export function wantedSearchString(query: WantedQuery): string {
  const params = new URLSearchParams()

  if (query.page > 0) params.set('page', String(query.page))
  if (query.size !== DEFAULT_SIZE) params.set('size', String(query.size))
  if (query.status) params.set('status', query.status)
  if (query.crewId) params.set('crewId', query.crewId)
  if (query.fruit) params.set('fruit', query.fruit)
  if (query.q.trim()) params.set('q', query.q.trim())
  if (query.sort !== DEFAULT_SORT) params.set('sort', query.sort)

  const serialized = params.toString()
  return serialized ? `?${serialized}` : ''
}

/** true si hay algun filtro o busqueda activa (para mostrar "limpiar filtros"). */
export function hasActiveFilters(query: WantedQuery): boolean {
  return Boolean(query.status || query.crewId || query.fruit || query.q.trim())
}
