import axios from 'axios'
import type { AxiosInstance } from 'axios'
import type { ApiErrorBody } from './types'

/**
 * La URL base NUNCA se escribe en el codigo: viene de la variable de entorno.
 * Si falta, fallamos rapido con un mensaje claro en vez de pedir a "undefined/...".
 */
const baseURL = import.meta.env.VITE_API_BASE_URL

if (!baseURL) {
  throw new Error(
    'Falta VITE_API_BASE_URL. Copia .env.example a .env y vuelve a lanzar npm run dev.',
  )
}

export const api: AxiosInstance = axios.create({ baseURL })

/* ---------- token en localStorage ---------- */

const TOKEN_KEY = 'logpose.token'

/** localStorage puede lanzar (modo privado, cookies bloqueadas): nunca tumbamos la app por eso. */
export function readToken(): string | null {
  try {
    return localStorage.getItem(TOKEN_KEY)
  } catch {
    return null
  }
}

export function writeToken(token: string): void {
  try {
    localStorage.setItem(TOKEN_KEY, token)
  } catch {
    /* sin persistencia: la sesion durara solo hasta recargar */
  }
}

export function clearToken(): void {
  try {
    localStorage.removeItem(TOKEN_KEY)
  } catch {
    /* nada que limpiar */
  }
}

/* ---------- aviso de sesion invalida ---------- */

type UnauthorizedListener = () => void
const unauthorizedListeners = new Set<UnauthorizedListener>()

/**
 * Permite que AuthContext reaccione a un 401 sin que esta capa sepa de React
 * ni recargue la pagina a mano.
 */
export function onUnauthorized(listener: UnauthorizedListener): () => void {
  unauthorizedListeners.add(listener)
  return () => {
    unauthorizedListeners.delete(listener)
  }
}

/* ---------- interceptores ---------- */

// Cada request sale con el token si existe. Asi ninguna pantalla tiene que
// acordarse de poner el header a mano.
api.interceptors.request.use((config) => {
  const token = readToken()
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

/** Rutas que funcionan sin sesion: un 401 aqui es "credenciales malas", no "sesion vencida". */
const PUBLIC_PATHS = ['/auth/login', '/auth/register']

api.interceptors.response.use(
  (response) => response,
  (error: unknown) => {
    if (axios.isAxiosError(error)) {
      const url = error.config?.url ?? ''
      const isPublic = PUBLIC_PATHS.some((path) => url.startsWith(path))
      if (error.response?.status === 401 && !isPublic) {
        clearToken()
        for (const listener of unauthorizedListeners) listener()
      }
    }
    return Promise.reject(error)
  },
)

/* ---------- normalizacion de errores ---------- */

export interface ParsedApiError {
  status: number | null
  code: string | null
  message: string
  /** details[] del contrato, convertido a { campo: mensaje } para pintarlo junto al input. */
  fieldErrors: Record<string, string>
  retryAfterSeconds: number | null
  /** true si no hubo respuesta del servidor (sin red, CORS, servidor dormido). */
  offline: boolean
}

const GENERIC_MESSAGE = 'No pudimos conectar con la API. Revisa tu conexion e intenta de nuevo.'

export function parseApiError(error: unknown): ParsedApiError {
  if (axios.isAxiosError<ApiErrorBody>(error)) {
    const body = error.response?.data
    const status = error.response?.status ?? null

    const fieldErrors: Record<string, string> = {}
    if (body && Array.isArray(body.details)) {
      for (const detail of body.details) {
        if (detail && typeof detail.field === 'string') {
          fieldErrors[detail.field] = detail.message
        }
      }
    }

    return {
      status,
      code: body?.code ?? null,
      message: body?.message ?? (status ? `Error ${status} al hablar con la API.` : GENERIC_MESSAGE),
      fieldErrors,
      retryAfterSeconds: body?.retryAfterSeconds ?? null,
      offline: !error.response,
    }
  }

  return {
    status: null,
    code: null,
    message: error instanceof Error ? error.message : GENERIC_MESSAGE,
    fieldErrors: {},
    retryAfterSeconds: null,
    offline: true,
  }
}

/** Una peticion abortada no es un error que haya que mostrar. */
export function isAbort(error: unknown): boolean {
  return (
    axios.isCancel(error) ||
    (error instanceof Error && (error.name === 'CanceledError' || error.name === 'AbortError'))
  )
}
