// Tipos copiados del contrato publico de la API (Swagger /docs).
// Las listas `as const` sirven dos propositos: generar el tipo union y poder
// validar en tiempo de ejecucion los valores que llegan por la URL.

/* ---------- enums del contrato ---------- */

export const WANTED_STATUSES = ['AT_LARGE', 'CAPTURED', 'MISSING'] as const
export type WantedStatus = (typeof WANTED_STATUSES)[number]

/** Tipos reales de fruta que puede traer un cartel. */
export const FRUIT_TYPES = ['PARAMECIA', 'ZOAN', 'LOGIA'] as const
export type FruitType = (typeof FRUIT_TYPES)[number]

/** Valores aceptados por el filtro `fruit`: incluye NONE (sin fruta). */
export const FRUIT_FILTERS = ['PARAMECIA', 'ZOAN', 'LOGIA', 'NONE'] as const
export type FruitFilter = (typeof FRUIT_FILTERS)[number]

export const CREW_ROLES = [
  'CAPTAIN',
  'FIRST_MATE',
  'NAVIGATOR',
  'SNIPER',
  'COOK',
  'DOCTOR',
  'SHIPWRIGHT',
  'MUSICIAN',
  'ARCHAEOLOGIST',
  'HELMSMAN',
  'FIGHTER',
] as const
export type CrewRole = (typeof CREW_ROLES)[number]

export const LOG_POSE_STATUSES = ['LOCKED', 'UNLOCKED'] as const
export type LogPoseStatus = (typeof LOG_POSE_STATUSES)[number]

/* ---------- parametros de /wanted ---------- */

export const WANTED_SORTS = ['bounty,desc', 'name,asc', 'updatedAt,desc'] as const
export type WantedSort = (typeof WANTED_SORTS)[number]

export const PAGE_SIZES = [10, 20, 50] as const
export type PageSize = (typeof PAGE_SIZES)[number]

/** Defaults del contrato. */
export const DEFAULT_SORT: WantedSort = 'bounty,desc'
export const DEFAULT_SIZE: PageSize = 20
/** `q` busca en name y epithet; el contrato lo limita a 80 caracteres. */
export const MAX_QUERY_LENGTH = 80

/* ---------- auth ---------- */

export interface User {
  id: string
  name: string
  email: string
}

export interface Team {
  code: string
  name: string
}

export interface LoginResponse {
  token: string
  tokenType: 'Bearer'
  expiresAt: string
  user: User
  team: Team
}

export interface MeResponse {
  user: User
  team: Team
  expiresAt: string
}

/* ---------- log pose y dashboard ---------- */

export interface LogPose {
  status: LogPoseStatus
  grandLineUnlocked: boolean
  unlockedAt: string | null
  message: string
}

export interface Crew {
  id: string
  name: string
  shipName: string
  jollyRogerColor: string
  memberCount: number
  totalBounty: number
}

export interface DashboardSummary {
  team: Team
  wanted: {
    total: number
    totalBounty: number
    averageBounty: number
    byStatus: Record<WantedStatus, number>
    byFruit: Record<FruitType | 'NONE', number>
  }
  crews: {
    total: number
    mostWanted: Crew | null
  }
  topBounties: WantedSummary[]
  generatedAt: string
}

/* ---------- carteles ---------- */

export interface CrewRef {
  id: string
  name: string
}

export interface DevilFruit {
  name: string
  type: FruitType
}

export interface WantedSummary {
  id: string
  name: string
  epithet: string
  bounty: number
  status: WantedStatus
  crew: CrewRef
  role: CrewRole
  devilFruit: DevilFruit | null
  threatLevel: number
  lastSeenIsland: string
  updatedAt: string
}

export interface WantedDetail extends WantedSummary {
  age: number
  heightCm: number
  bio: string
  lastSeen: {
    island: string
    seenAt: string
  }
  bountyHistory: Array<{
    amount: number
    issuedAt: string
  }>
}

export interface WantedPage {
  content: WantedSummary[]
  totalElements: number
  totalPages: number
  page: number
  size: number
}

/* ---------- errores ---------- */

export interface ApiFieldError {
  field: string
  message: string
}

/** Cuerpo de error unico de la API, igual en todas las rutas. */
export interface ApiErrorBody {
  status: number
  code: string
  message: string
  traceId: string
  details?: ApiFieldError[]
  retryAfterSeconds?: number
}
