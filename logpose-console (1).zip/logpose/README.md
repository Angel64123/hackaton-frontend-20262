# Log Pose Console

Consola de la Guild de Cazarrecompensas. React + TypeScript + Vite + React Router + Tailwind,
consumiendo la API del curso con Axios.

## Integrantes

| Nombre | Código |
| ------ | ------ |
| …      | …      |
| …      | …      |
| …      | …      |

Código de la tripulación: `TEAM-XXX`

## Cómo ejecutar

Requiere Node 24 LTS.

```bash
npm install
cp .env.example .env     # ya trae la URL de la API del curso
npm run dev              # http://localhost:5173
```

Otros comandos:

```bash
npm run typecheck        # tsc sin emitir: TypeScript estricto, sin any
npm run build            # tsc -b && vite build
npm run preview          # sirve dist/ como en producción
```

## Variables de entorno

| Variable            | Para qué                                                      |
| ------------------- | ------------------------------------------------------------- |
| `VITE_API_BASE_URL` | URL base de la API. La app la lee con `import.meta.env`, nunca escrita en el código. |

La contraseña de la tripulación no está en el repositorio: se escribe en la pantalla de login.

## Estructura

Cubre el **CP1 (Zarpar)** y el **CP2 (Carteles de «Se Busca»)**.

```
src/
  lib/          types.ts (contrato), api.ts (axios + interceptores),
                wantedQuery.ts (estado de la URL), format.ts
  auth/         AuthContext (sesión), RequireAuth (rutas privadas)
  logpose/      estado del Log Pose, que muestra el dashboard
  hooks/        useApiResource, useDebouncedValue
  components/   Layout, States (carga / error / vacío)
  pages/        una por ruta
```

## Decisiones técnicas

**La URL es el estado.** En `/wanted` y `/news` los filtros, la búsqueda, el orden, el tamaño
y la página viven en la query string, no en `useState`. No hay dos copias del estado que
puedan desincronizarse, así que recargar, compartir el enlace y usar atrás y adelante dan
exactamente la misma vista.

**La URL se sanea antes de usarla.** `parseWantedQuery` descarta cualquier valor fuera del
contrato (`?size=7`, `?sort=precio`, `?page=-5`) y cae al default. Así una URL manipulada ni
rompe la vista ni provoca un 400, porque a la API solo salen valores válidos.

**Dos defensas contra respuestas viejas.** Cada petición lleva un `AbortController` que la
cancela cuando deja de interesar, y además un número de orden: al volver, una respuesta solo
escribe en el estado si sigue siendo la última que se pidió. La segunda defensa es la que
cuenta, porque una petición ya en camino puede resolverse igual después de abortarla.

**Búsqueda con debounce.** El input tiene su propio estado y solo llega a la URL cuando el
usuario deja de teclear 350 ms, con `replace` para no llenar el historial. Una palabra de
siete letras genera una request, no siete.

**Cambiar de filtro borra `page`.** Filtrar desde la página 5 dejaría al usuario en una página
que con el filtro nuevo quizá no existe. Además, si la respuesta indica que la página pedida ya
no existe, la vista corrige a la última válida.

**El token lo pone un interceptor.** Ninguna pantalla escribe el header `Authorization`. Un
interceptor de respuesta detecta el 401 de sesión vencida, limpia el token y avisa al
`AuthContext`, que devuelve la app al login; el 401 de credenciales malas en `/auth/login` se
excluye para que el error se vea en el formulario.

**Restaurar sesión sin parpadeo.** El `AuthContext` arranca en `checking` cuando hay token
guardado y pregunta a `/auth/me`. Mientras tanto las rutas privadas muestran un splash, nunca
el login: el usuario no ve su sesión caerse y volver.

**Volver exactamente a donde se quería ir.** `RequireAuth` guarda la ubicación completa
(ruta, query string y hash) y el login redirige ahí. Al conservar el search, un enlace a
`/wanted?status=CAPTURED` devuelve ese listado filtrado, no el genérico.
