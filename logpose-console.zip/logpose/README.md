# Log Pose Console

Consola de la Guild de Cazarrecompensas. React + TypeScript + Vite + React Router + Tailwind,
consumiendo la API del curso con Axios.

## Integrantes

| Nombre | Código |
| ------ | ------ |
| …      | …      |
| …      | …      |
| …      | …      |

Código de la tripulación: `TEAM-XXX`

## Cómo ejecutar

Requiere Node 24 LTS.

```bash
npm install
cp .env.example .env     # ya trae la URL de la API del curso
npm run dev              # http://localhost:5173
```

Otros comandos:

```bash
npm run typecheck        # tsc sin emitir: TypeScript estricto, sin any
npm run build            # tsc -b && vite build
npm run preview          # sirve dist/ como en producción
```

## Variables de entorno

| Variable            | Para qué                                                      |
| ------------------- | ------------------------------------------------------------- |
| `VITE_API_BASE_URL` | URL base de la API. La app la lee con `import.meta.env`, nunca escrita en el código. |

La contraseña de la tripulación no está en el repositorio: se escribe en la pantalla de login.

## Estructura

```
src/
  lib/          types.ts (contrato), api.ts (axios + interceptores),
                wantedQuery.ts y newsQuery.ts (estado de la URL), format.ts
  auth/         AuthContext (sesión), RequireAuth (rutas privadas)
  logpose/      estado del Log Pose, compartido con la barra de navegación
  news/         estado del feed, montado sobre las rutas para sobrevivir al detalle
  hooks/        useApiResource, useDebouncedValue, usePrefersReducedMotion,
                useViewTransitionNavigate, useScrollDrivenSupport
  components/   Layout, States (carga / error / vacío / bloqueo), SagaMap
  pages/        una por ruta
```

## Decisiones técnicas

**La URL es el estado.** En `/wanted` y `/news` los filtros, la búsqueda, el orden, el tamaño
y la página viven en la query string, no en `useState`. No hay dos copias del estado que
puedan desincronizarse, así que recargar, compartir el enlace y usar atrás y adelante dan
exactamente la misma vista.

**La URL se sanea antes de usarla.** `parseWantedQuery` descarta cualquier valor fuera del
contrato (`?size=7`, `?sort=precio`, `?page=-5`) y cae al default. Así una URL manipulada ni
rompe la vista ni provoca un 400, porque a la API solo salen valores válidos.

**Dos defensas contra respuestas viejas.** Cada petición lleva un `AbortController` que la
cancela cuando deja de interesar, y además un número de orden: al volver, una respuesta solo
escribe en el estado si sigue siendo la última que se pidió. La segunda defensa es la que
cuenta, porque una petición ya en camino puede resolverse igual después de abortarla.

**Búsqueda con debounce.** El input tiene su propio estado y solo llega a la URL cuando el
usuario deja de teclear 350 ms, con `replace` para no llenar el historial. Una palabra de
siete letras genera una request, no siete.

**Cambiar de filtro borra `page`.** Filtrar desde la página 5 dejaría al usuario en una página
que con el filtro nuevo quizá no existe. Además, si la respuesta indica que la página pedida ya
no existe, la vista corrige a la última válida.

**El token lo pone un interceptor.** Ninguna pantalla escribe el header `Authorization`. Un
interceptor de respuesta detecta el 401 de sesión vencida, limpia el token y avisa al
`AuthContext`, que devuelve la app al login; el 401 de credenciales malas en `/auth/login` se
excluye para que el error se vea en el formulario.

**Restaurar sesión sin parpadeo.** El `AuthContext` arranca en `checking` cuando hay token
guardado y pregunta a `/auth/me`. Mientras tanto las rutas privadas muestran un splash, nunca
el login: el usuario no ve su sesión caerse y volver.

**Volver exactamente a donde se quería ir.** `RequireAuth` guarda la ubicación completa
(ruta, query string y hash) y el login redirige ahí. Al conservar el search, un enlace a
`/wanted?status=CAPTURED` devuelve ese listado filtrado, no el genérico.

**El 423 no es un error.** Hasta aprobar la inspección de Reverse Mountain, el Grand Line
responde `423 LOG_POSE_REQUIRED`. La app lo distingue de un fallo y muestra el bloqueo, y la
barra de navegación marca con candado los tramos cerrados.

**El feed vive por encima de las rutas.** `NewsFeedProvider` se monta sobre `/news` y
`/news/:id`, no dentro de la página del feed. Al abrir el detalle la página se desmonta, pero
el estado sigue en el provider: volver no cuesta ni una request y no se pierden las páginas
ya cargadas.

**Una sola carga en vuelo, y nada repetido.** Un candado (`inFlightRef`) impide que el
`IntersectionObserver`, que se dispara muchas veces durante un scroll rápido, lance varias
peticiones con el mismo cursor. Al concatenar, un `Set` de ids descarta lo repetido.

**Cambiar de filtro no mezcla resultados.** Un contador de generación: cada petición guarda la
generación con la que salió y, al volver, se descarta si la generación ya cambió. El cursor
queda ligado a sus filtros, así que un filtro nuevo reinicia el feed desde cero; si aun así la
API responde `INVALID_CURSOR` o `CURSOR_FILTER_MISMATCH`, se suelta el cursor y se pide el
feed otra vez, una sola vez para no entrar en bucle.

**La posición del feed se apunta en el click, no con un listener de scroll.** Al salir de la
lista el documento se encoge y el navegador dispara un scroll a 0; un listener atraparía ese 0
y pisaría la posición buena. El click ocurre antes de que nada se mueva.

**La ruta del mapa se dibuja sin medir píxeles.** El `<path>` lleva `pathLength={1}`, que
normaliza su largo a 1, así que `strokeDashoffset` va de 1 (nada dibujado) a 0 (todo dibujado)
y el progreso sale directo de la etapa activa.

**Scroll-driven animations con alternativa equivalente.** `CSS.supports` decide quién manda:
si el navegador soporta `animation-timeline`, el CSS anima la barra de progreso y la entrada de
cada etapa sin JavaScript; si no, React calcula el progreso con un listener de scroll. La
pantalla indica cuál de los dos está activo.

**La etapa inicial se lee en el primer render.** Si se leyera en un efecto, el efecto que
sincroniza la URL correría antes con la etapa 1, sobrescribiría `?stage` y cancelaría el salto.
Leerla al construir el estado elimina esa carrera.

**View Transition API opcional.** `document.startViewTransition` existe o no; si no, se navega
normal. El `flushSync` es necesario porque la transición necesita que el DOM ya haya cambiado
dentro del callback. Con `prefers-reduced-motion` se salta a propósito.
