import { useCallback, useState } from 'react'
import { Link, useLocation, useNavigate, useParams } from 'react-router-dom'
import { api, isLogPoseRequired, parseApiError } from '../lib/api'
import { useApiResource } from '../hooks/useApiResource'
import { useNewsFeed } from '../news/NewsFeedContext'
import {
  NEWS_PRIORITY_CLASS,
  NEWS_PRIORITY_LABEL,
  NEWS_STATUS_CLASS,
  NEWS_STATUS_LABEL,
  NEWS_TYPE_LABEL,
  formatDateTime,
} from '../lib/format'
import { NEWS_VERDICTS } from '../lib/types'
import type { NewsDetail, NewsVerdict } from '../lib/types'
import {
  Badge,
  ErrorState,
  LoadingState,
  LogPoseLockedState,
  Spinner,
} from '../components/States'

interface DetailState {
  feedSearch?: string
}

const VERDICT_LABEL: Record<NewsVerdict, string> = {
  CONFIRMED: 'Confirmar',
  DEBUNKED: 'Desmentir',
}

const VERDICT_DONE: Record<NewsVerdict, string> = {
  CONFIRMED: 'Noticia confirmada. Ya consta como verificada.',
  DEBUNKED: 'Noticia desmentida. Ya consta como verificada.',
}

export function NewsDetailPage() {
  const { id } = useParams<{ id: string }>()
  const location = useLocation()
  const navigate = useNavigate()
  const { applyNewsUpdate } = useNewsFeed()

  const state = location.state as DetailState | null
  const feedUrl = `/news${state?.feedSearch ?? ''}`
  const cameFromApp = location.key !== 'default'

  const { data, loading, error, reload, replace } = useApiResource<NewsDetail>(
    id ? `/news/${id}` : null,
  )

  /** Veredicto en vuelo: mientras no sea null, los dos botones se deshabilitan. */
  const [pending, setPending] = useState<NewsVerdict | null>(null)
  const [actionError, setActionError] = useState<string | null>(null)
  const [confirmation, setConfirmation] = useState<string | null>(null)
  /** El ultimo veredicto que fallo, para que "Reintentar" sepa qué repetir. */
  const [failedVerdict, setFailedVerdict] = useState<NewsVerdict | null>(null)

  const verify = useCallback(
    async (verdict: NewsVerdict) => {
      if (!id) return

      setPending(verdict)
      setActionError(null)
      setConfirmation(null)

      try {
        const response = await api.patch<NewsDetail>(`/news/${id}/status`, { status: verdict })

        // Solo al salir bien se sustituye la noticia. Si falla, el estado
        // anterior sigue intacto en pantalla.
        replace(response.data)
        applyNewsUpdate(response.data)
        setConfirmation(VERDICT_DONE[verdict])
        setFailedVerdict(null)
      } catch (err) {
        const parsed = parseApiError(err)

        if (parsed.status === 409 && parsed.current) {
          // Ya la verifico otra persona con el otro veredicto. El contrato
          // devuelve en `current` como esta ahora: se muestra eso.
          replace(parsed.current)
          applyNewsUpdate(parsed.current)
          setActionError(
            `Esta noticia ya estaba verificada como ${NEWS_STATUS_LABEL[parsed.current.status]}. Se actualizó lo que ves.`,
          )
          setFailedVerdict(null)
        } else if (parsed.status === 429) {
          setActionError(
            `Demasiadas peticiones seguidas. Espera ${parsed.retryAfterSeconds ?? 30} s y reintenta.`,
          )
          setFailedVerdict(verdict)
        } else {
          setActionError(parsed.message)
          setFailedVerdict(verdict)
        }
      } finally {
        setPending(null)
      }
    },
    [id, replace, applyNewsUpdate],
  )

  function goBack() {
    if (cameFromApp) {
      navigate(-1)
    } else {
      navigate(feedUrl, { replace: true })
    }
  }

  if (error && isLogPoseRequired(error)) {
    return <LogPoseLockedState message={error.message} />
  }

  const isRumor = data?.status === 'RUMOR'

  return (
    <div className="space-y-6">
      <button
        type="button"
        onClick={goBack}
        className="rounded-lg border border-white/10 px-3 py-1.5 text-sm text-slate-300 transition hover:bg-white/5 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-amber-300"
      >
        ← Volver al feed
      </button>

      {loading && !data && <LoadingState label="Cargando la noticia…" />}

      {error && !data && (
        <ErrorState
          error={error}
          onRetry={error.status === 404 ? undefined : reload}
          title={error.status === 404 ? 'Esta noticia no existe' : 'No pudimos cargar la noticia'}
        />
      )}

      {data && (
        <article className="space-y-6">
          <header className="rounded-2xl border border-white/10 bg-white/[0.02] p-6">
            <div className="flex flex-wrap items-center gap-2">
              <Badge className="bg-white/5 text-slate-300 ring-white/10">
                {NEWS_TYPE_LABEL[data.type]}
              </Badge>
              <Badge className={NEWS_PRIORITY_CLASS[data.priority]}>
                {NEWS_PRIORITY_LABEL[data.priority]}
              </Badge>
              <Badge className={NEWS_STATUS_CLASS[data.status]}>
                {NEWS_STATUS_LABEL[data.status]}
              </Badge>
            </div>

            <h1 className="mt-4 text-2xl font-semibold tracking-tight text-slate-50">
              {data.title}
            </h1>
            <p className="mt-2 text-slate-400">{data.summary}</p>

            <dl className="mt-5 grid gap-x-6 gap-y-2 text-sm sm:grid-cols-2">
              <Row label="Fuente" value={data.source} />
              <Row label="Isla" value={data.island} />
              <Row label="Publicada" value={formatDateTime(data.publishedAt)} />
              <Row label="Actualizada" value={formatDateTime(data.updatedAt)} />
              {data.verifiedAt && (
                <Row label="Verificada" value={formatDateTime(data.verifiedAt)} />
              )}
            </dl>

            <p className="mt-4 text-sm text-slate-400">
              Relacionada con{' '}
              <Link
                to={`/wanted/${data.relatedWanted.id}`}
                className="font-medium text-amber-300 underline-offset-4 hover:underline"
              >
                {data.relatedWanted.name}
              </Link>
            </p>
          </header>

          <section className="space-y-4 rounded-2xl border border-white/10 bg-white/[0.02] p-6">
            {data.body.map((paragraph, index) => (
              <p key={index} className="leading-relaxed text-slate-300">
                {paragraph}
              </p>
            ))}
          </section>

          {/* ---------- verificar el rumor ---------- */}
          <section
            aria-labelledby="verify-heading"
            className="rounded-2xl border border-white/10 bg-white/[0.02] p-6"
          >
            <h2
              id="verify-heading"
              className="text-sm font-semibold tracking-wide text-slate-300 uppercase"
            >
              Verificación
            </h2>

            {isRumor ? (
              <>
                <p className="mt-2 text-sm text-slate-400">
                  Esta noticia sigue siendo un rumor. Decide si la Guild la confirma o la desmiente.
                </p>

                <div className="mt-4 flex flex-wrap gap-3">
                  {NEWS_VERDICTS.map((verdict) => (
                    <button
                      key={verdict}
                      type="button"
                      // Mientras hay una request en vuelo, los dos botones se
                      // deshabilitan: no se puede mandar dos veredictos a la vez.
                      disabled={pending !== null}
                      onClick={() => verify(verdict)}
                      className={`flex items-center gap-2 rounded-lg px-4 py-2 text-sm font-medium transition disabled:cursor-not-allowed disabled:opacity-50 focus-visible:outline-2 focus-visible:outline-offset-2 ${
                        verdict === 'CONFIRMED'
                          ? 'bg-emerald-500/20 text-emerald-100 ring-1 ring-emerald-400/40 hover:bg-emerald-500/30 focus-visible:outline-emerald-300'
                          : 'bg-slate-500/20 text-slate-100 ring-1 ring-slate-400/40 hover:bg-slate-500/30 focus-visible:outline-slate-300'
                      }`}
                    >
                      {pending === verdict && <Spinner className="h-4 w-4" />}
                      {pending === verdict ? 'Enviando…' : VERDICT_LABEL[verdict]}
                    </button>
                  ))}
                </div>
              </>
            ) : (
              <p className="mt-2 text-sm text-slate-400">
                Ya está verificada como{' '}
                <span className="font-medium text-slate-200">
                  {NEWS_STATUS_LABEL[data.status]}
                </span>
                {data.verifiedAt ? ` el ${formatDateTime(data.verifiedAt)}` : ''}. Solo un rumor se
                puede verificar.
              </p>
            )}

            {confirmation && (
              <p
                className="mt-4 rounded-lg border border-emerald-400/30 bg-emerald-400/10 px-4 py-3 text-sm text-emerald-100"
                role="status"
              >
                ✓ {confirmation}
              </p>
            )}

            {actionError && (
              <div
                className="mt-4 rounded-lg border border-rose-500/30 bg-rose-500/10 px-4 py-3"
                role="alert"
              >
                <p className="text-sm text-rose-100">{actionError}</p>
                {failedVerdict && (
                  <button
                    type="button"
                    disabled={pending !== null}
                    onClick={() => verify(failedVerdict)}
                    className="mt-3 rounded-lg bg-rose-500/20 px-3 py-1.5 text-sm font-medium text-rose-50 ring-1 ring-rose-400/40 transition hover:bg-rose-500/30 disabled:opacity-50"
                  >
                    Reintentar «{VERDICT_LABEL[failedVerdict]}»
                  </button>
                )}
              </div>
            )}
          </section>
        </article>
      )}
    </div>
  )
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex gap-2">
      <dt className="text-slate-500">{label}:</dt>
      <dd className="text-slate-200">{value}</dd>
    </div>
  )
}
