import { useCallback, useEffect, useLayoutEffect, useMemo, useRef } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import { isLogPoseRequired } from '../lib/api'
import { useNewsFeed } from '../news/NewsFeedContext'
import { hasNewsFilters, newsSearchString, parseNewsFilters } from '../lib/newsQuery'
import {
  NEWS_PRIORITY_CLASS,
  NEWS_PRIORITY_LABEL,
  NEWS_STATUS_CLASS,
  NEWS_STATUS_LABEL,
  NEWS_TYPE_LABEL,
  formatDateTime,
} from '../lib/format'
import { NEWS_PRIORITIES, NEWS_STATUSES, NEWS_TYPES } from '../lib/types'
import type { NewsItem } from '../lib/types'
import {
  Badge,
  EmptyState,
  ErrorState,
  LoadingState,
  LogPoseLockedState,
  Spinner,
} from '../components/States'
import { usePrefersReducedMotion } from '../hooks/usePrefersReducedMotion'

type FilterKey = 'type' | 'priority' | 'status'

export function NewsFeedPage() {
  const [searchParams, setSearchParams] = useSearchParams()
  const filters = useMemo(() => parseNewsFilters(searchParams), [searchParams])

  const {
    items,
    hasMore,
    loading,
    error,
    initialized,
    syncFilters,
    loadMore,
    retry,
    saveScroll,
    getSavedScroll,
  } = useNewsFeed()

  const prefersReducedMotion = usePrefersReducedMotion()
  const sentinelRef = useRef<HTMLDivElement | null>(null)
  const restoredRef = useRef(false)

  // Los filtros de la URL mandan. Si son los mismos que el provider ya tiene
  // cargados, esta llamada no pide nada.
  useEffect(() => {
    syncFilters(filters)
  }, [filters, syncFilters])

  /**
   * Observer del centinela al final de la lista: cuando entra en pantalla
   * (400px antes, para que la carga no se note), pide la pagina siguiente.
   * No es un boton "Cargar mas": el usuario solo hace scroll.
   */
  useEffect(() => {
    const sentinel = sentinelRef.current
    if (!sentinel) return

    const observer = new IntersectionObserver(
      (entries) => {
        if (entries.some((entry) => entry.isIntersecting)) {
          // Los candados de "una sola carga en vuelo" y "no reintentar tras
          // error" estan dentro del provider, no aqui.
          loadMore()
        }
      },
      { rootMargin: '400px 0px' },
    )

    observer.observe(sentinel)
    return () => {
      observer.disconnect()
    }
  }, [loadMore])

  /**
   * Al volver del detalle, el feed recupera la posicion que se apunto al
   * abrirlo (ver `onOpen` en las filas de abajo).
   *
   * Es useLayoutEffect y no useEffect porque corre justo despues de que React
   * escribio las filas en el DOM y antes de que el navegador pinte: la pagina
   * ya tiene su alto real, asi que el scroll cae en su sitio sin parpadeo.
   */
  useLayoutEffect(() => {
    if (restoredRef.current || items.length === 0) return
    restoredRef.current = true

    const saved = getSavedScroll()
    if (saved <= 0) return

    window.scrollTo({ top: saved, behavior: 'auto' })
  }, [getSavedScroll, items.length])

  const setFilter = useCallback(
    (key: FilterKey, value: string | null) => {
      setSearchParams(
        (previous) => {
          const next = new URLSearchParams(previous)
          if (value) next.set(key, value)
          else next.delete(key)
          return next
        },
        { replace: false },
      )
      // Cambiar de filtro vuelve arriba: la lista es otra.
      window.scrollTo({ top: 0, behavior: prefersReducedMotion ? 'auto' : 'smooth' })
    },
    [setSearchParams, prefersReducedMotion],
  )

  const clearFilters = useCallback(() => {
    setSearchParams(new URLSearchParams())
  }, [setSearchParams])

  const feedSearch = newsSearchString(filters)
  const filtersActive = hasNewsFilters(filters)

  // 423 no es un fallo de la app: es el Grand Line cerrado hasta el CP3.
  if (error && isLogPoseRequired(error)) {
    return <LogPoseLockedState message={error.message} />
  }

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-2xl font-semibold tracking-tight text-slate-50">
          News Coo · Noticias del mundo
        </h1>
        <p className="mt-1 text-sm text-slate-400">
          {items.length > 0
            ? `${items.length} noticias cargadas${hasMore ? ' · sigue bajando' : ' · fin de la lista'}`
            : 'El feed se carga solo al llegar al final.'}
        </p>
      </header>

      <section
        aria-label="Filtros del feed"
        className="grid gap-4 rounded-2xl border border-white/10 bg-white/[0.02] p-4 sm:grid-cols-3 sm:p-5"
      >
        <FilterSelect
          id="type"
          label="Tipo"
          value={filters.type}
          options={NEWS_TYPES.map((type) => ({ value: type, label: NEWS_TYPE_LABEL[type] }))}
          onChange={(value) => setFilter('type', value)}
        />
        <FilterSelect
          id="priority"
          label="Prioridad"
          value={filters.priority}
          options={NEWS_PRIORITIES.map((priority) => ({
            value: priority,
            label: NEWS_PRIORITY_LABEL[priority],
          }))}
          onChange={(value) => setFilter('priority', value)}
        />
        <FilterSelect
          id="status"
          label="Estado"
          value={filters.status}
          options={NEWS_STATUSES.map((status) => ({
            value: status,
            label: NEWS_STATUS_LABEL[status],
          }))}
          onChange={(value) => setFilter('status', value)}
        />

        {filtersActive && (
          <div className="sm:col-span-3">
            <button
              type="button"
              onClick={clearFilters}
              className="rounded-lg border border-white/10 px-3 py-2 text-sm text-slate-300 transition hover:bg-white/5 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-amber-300"
            >
              Limpiar filtros
            </button>
          </div>
        )}
      </section>

      {/* Primera carga: nada que conservar todavia. */}
      {!initialized && loading && <LoadingState label="Cargando el feed…" rows={4} />}

      {initialized && items.length === 0 && !error && (
        <EmptyState
          title="No hay noticias con estos filtros"
          hint={filtersActive ? 'Prueba quitando alguno.' : 'El News Coo todavía no trajo nada.'}
        />
      )}

      {items.length > 0 && (
        <ul className="space-y-3">
          {items.map((item) => (
            <li key={item.id}>
              <NewsRow
                item={item}
                feedSearch={feedSearch}
                /*
                 * La posicion se apunta aqui, en el click, y no con un listener
                 * de scroll. Al salir de esta pagina el documento se encoge
                 * (el detalle es mas corto) y el navegador dispara un scroll a
                 * 0; un listener atraparia ese 0 y pisaria la posicion buena.
                 * El click ocurre antes de que nada se mueva.
                 */
                onOpen={() => saveScroll(window.scrollY)}
              />
            </li>
          ))}
        </ul>
      )}

      {/* Pie del feed: carga, error con reintento o fin de la lista. */}
      <div className="py-4">
        {loading && initialized && (
          <p className="flex items-center justify-center gap-2 text-sm text-slate-400" role="status">
            <Spinner className="h-4 w-4 text-amber-300" />
            Cargando más noticias…
          </p>
        )}

        {error && (
          <ErrorState
            error={error}
            onRetry={retry}
            title={
              items.length > 0
                ? 'No pudimos traer más noticias'
                : 'No pudimos cargar el feed'
            }
          />
        )}

        {!hasMore && !loading && !error && items.length > 0 && (
          <p className="text-center text-sm text-slate-500">
            Fin del feed · {items.length} noticias
          </p>
        )}
      </div>

      {/* Centinela: lo observa el IntersectionObserver de arriba. */}
      <div ref={sentinelRef} aria-hidden="true" className="h-px" />
    </div>
  )
}

function FilterSelect({
  id,
  label,
  value,
  options,
  onChange,
}: {
  id: string
  label: string
  value: string | null
  options: Array<{ value: string; label: string }>
  onChange: (value: string | null) => void
}) {
  return (
    <div>
      <label htmlFor={id} className="block text-xs font-semibold tracking-wide text-slate-400 uppercase">
        {label}
      </label>
      <select
        id={id}
        value={value ?? ''}
        onChange={(event) => onChange(event.target.value || null)}
        className="mt-1.5 w-full rounded-lg border border-white/10 bg-slate-950/60 px-3 py-2 text-sm text-slate-100 outline-none transition focus:border-amber-300/60"
      >
        <option value="">Todos</option>
        {options.map((option) => (
          <option key={option.value} value={option.value}>
            {option.label}
          </option>
        ))}
      </select>
    </div>
  )
}

function NewsRow({
  item,
  feedSearch,
  onOpen,
}: {
  item: NewsItem
  feedSearch: string
  onOpen: () => void
}) {
  return (
    <Link
      to={`/news/${item.id}`}
      state={{ feedSearch }}
      onClick={onOpen}
      className="block rounded-xl border border-white/10 bg-white/[0.02] p-4 transition hover:border-amber-300/40 hover:bg-white/[0.04] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-amber-300"
    >
      <div className="flex flex-wrap items-center gap-2">
        <Badge className="bg-white/5 text-slate-300 ring-white/10">{NEWS_TYPE_LABEL[item.type]}</Badge>
        <Badge className={NEWS_PRIORITY_CLASS[item.priority]}>
          {NEWS_PRIORITY_LABEL[item.priority]}
        </Badge>
        <Badge className={NEWS_STATUS_CLASS[item.status]}>{NEWS_STATUS_LABEL[item.status]}</Badge>
        <span className="ml-auto text-xs text-slate-500">{formatDateTime(item.publishedAt)}</span>
      </div>

      <h2 className="mt-3 font-medium text-slate-50">{item.title}</h2>
      <p className="mt-1.5 text-sm leading-relaxed text-slate-400">{item.summary}</p>

      <p className="mt-3 text-xs text-slate-500">
        {item.source} · {item.island} · relacionado con {item.relatedWanted.name}
      </p>
    </Link>
  )
}
