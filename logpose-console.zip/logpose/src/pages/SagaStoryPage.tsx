import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import type { CSSProperties } from 'react'
import { Link, useParams, useSearchParams } from 'react-router-dom'
import { isLogPoseRequired } from '../lib/api'
import { useApiResource } from '../hooks/useApiResource'
import { usePrefersReducedMotion } from '../hooks/usePrefersReducedMotion'
import { SUPPORTS_SCROLL_TIMELINE, SUPPORTS_VIEW_TIMELINE } from '../hooks/useScrollDrivenSupport'
import { SagaMap } from '../components/SagaMap'
import { formatNumber } from '../lib/format'
import type { SagaStage, SagaStory, StageMetric } from '../lib/types'
import { ErrorState, LoadingState, LogPoseLockedState } from '../components/States'

export function SagaStoryPage() {
  const { id } = useParams<{ id: string }>()
  const { data, loading, error, reload } = useApiResource<SagaStory>(
    id ? `/sagas/${id}/story` : null,
  )

  if (error && isLogPoseRequired(error)) {
    return <LogPoseLockedState message={error.message} />
  }

  if (loading && !data) {
    return <LoadingState label="Descifrando el Poneglyph…" />
  }

  if (error && !data) {
    return (
      <ErrorState
        error={error}
        onRetry={error.status === 404 ? undefined : reload}
        title={error.status === 404 ? 'Esta saga no existe' : 'No pudimos cargar la saga'}
      />
    )
  }

  if (!data) return null

  // `key` fuerza un remonte limpio al cambiar de saga: el scroll, la etapa
  // activa y los observers vuelven a empezar.
  return <SagaStoryView key={data.saga.id} story={data} />
}

function SagaStoryView({ story }: { story: SagaStory }) {
  const [searchParams, setSearchParams] = useSearchParams()
  const prefersReducedMotion = usePrefersReducedMotion()

  const stages = story.stages

  /**
   * La etapa inicial se saca de la URL ya en el primer render, no en un efecto
   * posterior. Si se hiciera despues, el efecto que sincroniza la URL correria
   * antes con activeIndex = 0, sobrescribiria ?stage con la etapa 1 y, al
   * cambiar searchParams, cancelaria el salto que estaba a punto de ocurrir.
   */
  const [activeIndex, setActiveIndex] = useState(() => {
    const slug = searchParams.get('stage')
    if (!slug) return 0
    const index = stages.findIndex((stage) => stage.slug === slug)
    // Un slug que no existe se ignora: la historia empieza desde el principio.
    return index >= 0 ? index : 0
  })

  const [scrollProgress, setScrollProgress] = useState(0)

  const sectionRefs = useRef<Array<HTMLElement | null>>([])
  /** Etapa pedida en la URL al abrir, congelada en el primer render. */
  const initialIndexRef = useRef(activeIndex)
  /** Hasta que el salto inicial no se aplica, la URL no se toca. */
  const [deepLinkApplied, setDeepLinkApplied] = useState(() => initialIndexRef.current === 0)

  const activeStage: SagaStage | undefined = stages[activeIndex]

  /**
   * Quien maneja las animaciones ligadas al scroll.
   *
   * 'css': el navegador soporta scroll-driven animations y las reglas de
   *        index.css hacen el trabajo, sin JavaScript.
   * 'js':  no las soporta, asi que React calcula el progreso con un listener
   *        de scroll y el resultado visible es el mismo.
   */
  const progressDriver = SUPPORTS_SCROLL_TIMELINE ? 'css' : 'js'
  const revealDriver = SUPPORTS_VIEW_TIMELINE ? 'css' : 'js'

  /* ---------- etapa activa segun el scroll ---------- */

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (!entry.isIntersecting) continue
          const raw = (entry.target as HTMLElement).dataset.index
          if (raw === undefined) continue
          const index = Number(raw)
          if (Number.isInteger(index)) setActiveIndex(index)
        }
      },
      {
        // La franja -45%/-45% deja activa solo la seccion que cruza el centro
        // de la pantalla: asi la etapa activa es la que el usuario esta leyendo.
        rootMargin: '-45% 0px -45% 0px',
        threshold: 0,
      },
    )

    for (const section of sectionRefs.current) {
      if (section) observer.observe(section)
    }

    return () => {
      observer.disconnect()
    }
  }, [stages.length])

  /* ---------- la URL indica la etapa activa ---------- */

  // Salto inicial a la etapa que pide la URL. Un rAF para que las secciones
  // ya esten medidas cuando se calcula a donde hay que ir.
  useEffect(() => {
    if (deepLinkApplied) return

    const frame = requestAnimationFrame(() => {
      sectionRefs.current[initialIndexRef.current]?.scrollIntoView({
        behavior: 'auto',
        block: 'start',
      })
      setDeepLinkApplied(true)
    })

    return () => {
      cancelAnimationFrame(frame)
    }
  }, [deepLinkApplied])

  // Y al revés: al avanzar con el scroll, la URL se actualiza con `replace`
  // para no llenar el historial de una entrada por etapa.
  useEffect(() => {
    if (!deepLinkApplied) return

    const stage = stages[activeIndex]
    if (!stage) return
    if (searchParams.get('stage') === stage.slug) return

    const next = new URLSearchParams(searchParams)
    next.set('stage', stage.slug)
    setSearchParams(next, { replace: true })
  }, [activeIndex, stages, searchParams, setSearchParams, deepLinkApplied])

  /* ---------- progreso del recorrido (solo si el CSS no puede) ---------- */

  useEffect(() => {
    if (SUPPORTS_SCROLL_TIMELINE) return

    const handleScroll = () => {
      const element = document.documentElement
      const max = element.scrollHeight - element.clientHeight
      setScrollProgress(max > 0 ? Math.min(1, Math.max(0, element.scrollTop / max)) : 0)
    }

    handleScroll()
    window.addEventListener('scroll', handleScroll, { passive: true })
    window.addEventListener('resize', handleScroll)
    return () => {
      window.removeEventListener('scroll', handleScroll)
      window.removeEventListener('resize', handleScroll)
    }
  }, [])

  /* ---------- navegacion por teclado y por botones ---------- */

  const goToStage = useCallback(
    (index: number) => {
      const clamped = Math.min(stages.length - 1, Math.max(0, index))
      const section = sectionRefs.current[clamped]
      if (!section) return

      setActiveIndex(clamped)
      section.scrollIntoView({
        behavior: prefersReducedMotion ? 'auto' : 'smooth',
        block: 'start',
      })
      // Mover el foco deja al lector de pantalla y al teclado en la etapa
      // nueva. preventScroll evita que el navegador salte por su cuenta.
      section.focus({ preventScroll: true })
    },
    [stages.length, prefersReducedMotion],
  )

  /** Progreso de la ruta en el mapa, derivado de la etapa activa. */
  const routeProgress = useMemo(() => {
    if (stages.length <= 1) return 1
    return activeIndex / (stages.length - 1)
  }, [activeIndex, stages.length])

  const palette = activeStage?.palette ?? story.saga.palette

  // La paleta llega de la API: se inyecta como variables CSS y la usan el
  // mapa, los textos y los acentos. Cambiar de etapa cambia los colores.
  const paletteStyle: CSSProperties & Record<string, string> = {
    '--stage-bg': palette.background,
    '--stage-surface': palette.surface,
    '--stage-primary': palette.primary,
    '--stage-accent': palette.accent,
    '--stage-text': palette.text,
    backgroundColor: palette.background,
    color: palette.text,
  }

  const progressStyle: CSSProperties & Record<string, string> = {
    '--sdw-progress': String(progressDriver === 'js' ? scrollProgress : 1),
  }

  return (
    <div className="space-y-6">
      {/* Barra de progreso del recorrido, siempre visible. */}
      <div
        className="fixed inset-x-0 top-0 z-50 h-1 bg-black/40"
        role="progressbar"
        aria-label="Progreso de la saga"
        aria-valuemin={1}
        aria-valuemax={stages.length}
        aria-valuenow={activeIndex + 1}
      >
        <div
          className="journey-progress h-full bg-[var(--stage-accent)]"
          data-driver={progressDriver}
          style={{ ...progressStyle, backgroundColor: palette.accent }}
        />
      </div>

      <div className="flex flex-wrap items-center gap-3">
        <Link
          to="/sagas"
          className="rounded-lg border border-white/10 px-3 py-1.5 text-sm text-slate-300 transition hover:bg-white/5 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-amber-300"
        >
          ← Todas las sagas
        </Link>
        <p className="text-xs text-slate-500">
          Animaciones: {progressDriver === 'css' ? 'CSS scroll-driven' : 'equivalente en JS'}
          {prefersReducedMotion && ' · movimiento reducido'}
        </p>
      </div>

      <div
        style={paletteStyle}
        className="rounded-3xl p-5 ring-1 ring-white/10 transition-colors duration-700 sm:p-8"
      >
        {/* El mismo view-transition-name que la tarjeta: uno se convierte en el otro. */}
        <header style={{ viewTransitionName: `saga-${story.saga.id}` }}>
          <p
            className="text-xs font-semibold tracking-[0.2em] uppercase"
            style={{ color: palette.primary }}
          >
            Saga {story.saga.order} · {stages.length} etapas ·{' '}
            {formatNumber(story.saga.totalDistanceNm)} mn
          </p>
          <h1 className="mt-2 text-3xl font-semibold tracking-tight sm:text-4xl">
            {story.saga.title}
          </h1>
          <p className="mt-2 text-lg opacity-80">{story.saga.subtitle}</p>
          <p className="mt-5 max-w-prose leading-relaxed opacity-90">{story.saga.intro}</p>
        </header>

        {/* Navegacion por etapas: alcanzable con Tab y activable con Enter. */}
        <nav aria-label="Etapas de la saga" className="mt-8">
          <ol className="flex flex-wrap gap-2">
            {stages.map((stage, index) => (
              <li key={stage.id}>
                <button
                  type="button"
                  onClick={() => goToStage(index)}
                  aria-current={index === activeIndex ? 'step' : undefined}
                  className={`rounded-lg px-3 py-1.5 text-sm transition focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[var(--stage-accent)] ${
                    index === activeIndex
                      ? 'bg-[var(--stage-accent)] font-medium text-[var(--stage-bg)]'
                      : 'bg-white/5 opacity-70 hover:bg-white/10 hover:opacity-100'
                  }`}
                >
                  {stage.order}. {stage.island.name}
                </button>
              </li>
            ))}
          </ol>
        </nav>

        <div className="mt-8 lg:grid lg:grid-cols-2 lg:gap-10">
          {/*
            Mapa y metricas: pegados arriba en movil y como columna propia en
            desktop. En los dos casos acompanan la lectura todo el recorrido.
          */}
          <aside className="sticky top-14 z-20 -mx-5 mb-6 bg-[var(--stage-bg)]/95 px-5 py-4 backdrop-blur sm:-mx-8 sm:px-8 lg:order-2 lg:mx-0 lg:mb-0 lg:self-start lg:rounded-2xl lg:px-5 lg:top-20">
            <div className="h-48 sm:h-64 lg:h-[46vh]">
              <SagaMap
                map={story.map}
                stages={stages}
                activeIndex={activeIndex}
                routeProgress={routeProgress}
              />
            </div>

            {activeStage && <MetricsPanel stage={activeStage} total={stages.length} />}

            <div className="mt-4 flex items-center justify-between gap-3">
              <button
                type="button"
                onClick={() => goToStage(activeIndex - 1)}
                disabled={activeIndex === 0}
                className="rounded-lg bg-white/5 px-3 py-1.5 text-sm transition hover:bg-white/10 disabled:cursor-not-allowed disabled:opacity-40 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[var(--stage-accent)]"
              >
                ← Etapa anterior
              </button>
              <button
                type="button"
                onClick={() => goToStage(activeIndex + 1)}
                disabled={activeIndex >= stages.length - 1}
                className="rounded-lg bg-white/5 px-3 py-1.5 text-sm transition hover:bg-white/10 disabled:cursor-not-allowed disabled:opacity-40 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[var(--stage-accent)]"
              >
                Etapa siguiente →
              </button>
            </div>
          </aside>

          {/* Narrativa: una seccion por etapa. */}
          <div className="lg:order-1">
            {stages.map((stage, index) => (
              <section
                key={stage.id}
                id={`stage-${stage.slug}`}
                data-index={index}
                data-driver={revealDriver}
                tabIndex={-1}
                ref={(element) => {
                  sectionRefs.current[index] = element
                }}
                aria-label={`Etapa ${stage.order} de ${stages.length}: ${stage.title}`}
                className={`stage-reveal scroll-mt-24 border-t border-white/10 py-10 first:border-t-0 lg:min-h-[70vh] ${
                  index === activeIndex ? 'opacity-100' : 'opacity-60'
                } transition-opacity duration-500 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[var(--stage-accent)]`}
              >
                <p
                  className="text-xs font-semibold tracking-[0.2em] uppercase"
                  style={{ color: palette.primary }}
                >
                  Etapa {stage.order} de {stages.length} · {stage.island.name}
                </p>
                <h2 className="mt-2 text-2xl font-semibold tracking-tight">{stage.title}</h2>

                <div className="mt-4 space-y-4">
                  {stage.narrative.map((paragraph, paragraphIndex) => (
                    <p key={paragraphIndex} className="max-w-prose leading-relaxed opacity-90">
                      {paragraph}
                    </p>
                  ))}
                </div>

                {/*
                  Las metricas tambien se repiten aqui: con el mapa pegado
                  arriba en movil, esta copia asegura que los numeros de la
                  etapa esten junto a su texto y nunca se mezclen con otra.
                */}
                <dl className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-4 lg:hidden">
                  {stage.metrics.map((metric) => (
                    <div key={metric.key} className="rounded-xl bg-white/5 p-3">
                      <dt className="text-[0.7rem] opacity-60">{metric.label}</dt>
                      <dd className="mt-1 font-mono text-sm">{formatMetric(metric)}</dd>
                    </div>
                  ))}
                </dl>
              </section>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

/**
 * Metricas de la etapa activa. Se dibujan desde `stage`, asi que lo que se ve
 * siempre corresponde a esa etapa y no a una mezcla de varias.
 */
function MetricsPanel({ stage, total }: { stage: SagaStage; total: number }) {
  return (
    <div className="mt-4">
      <p className="text-xs font-semibold tracking-wide opacity-60 uppercase">
        Etapa {stage.order} de {total} · {stage.island.name}
      </p>
      <dl className="mt-3 hidden grid-cols-2 gap-3 lg:grid">
        {stage.metrics.map((metric) => (
          <div key={metric.key} className="rounded-xl bg-white/5 p-3">
            <dt className="text-[0.7rem] opacity-60">{metric.label}</dt>
            <dd className="mt-1 font-mono text-sm">{formatMetric(metric)}</dd>
          </div>
        ))}
      </dl>
    </div>
  )
}

function formatMetric(metric: StageMetric): string {
  const value =
    metric.value >= 1_000_000
      ? `${(metric.value / 1_000_000).toFixed(1)} M`
      : formatNumber(metric.value)
  return metric.unit ? `${value} ${metric.unit}` : value
}
