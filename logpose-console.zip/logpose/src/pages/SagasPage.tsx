import type { CSSProperties } from 'react'
import { isLogPoseRequired } from '../lib/api'
import { useApiResource } from '../hooks/useApiResource'
import { useViewTransitionNavigate } from '../hooks/useViewTransitionNavigate'
import { formatNumber } from '../lib/format'
import type { SagaSummary } from '../lib/types'
import { EmptyState, ErrorState, LoadingState, LogPoseLockedState } from '../components/States'

export function SagasPage() {
  const { data, loading, error, reload } = useApiResource<SagaSummary[]>('/sagas')
  const navigateWithTransition = useViewTransitionNavigate()

  if (error && isLogPoseRequired(error)) {
    return <LogPoseLockedState message={error.message} />
  }

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-2xl font-semibold tracking-tight text-slate-50">
          Poneglyph · Las grandes sagas
        </h1>
        <p className="mt-1 text-sm text-slate-400">
          Cada saga guarda su recorrido por el Grand Line. Entra para leerla etapa por etapa.
        </p>
      </header>

      {loading && !data && <LoadingState label="Cargando las sagas…" rows={3} />}

      {error && !data && <ErrorState error={error} onRetry={reload} />}

      {data && data.length === 0 && (
        <EmptyState
          title="Todavía no hay sagas registradas"
          hint="Cuando la Guild descifre un Poneglyph aparecerá aquí."
        />
      )}

      {data && data.length > 0 && (
        <ul className="grid gap-5 lg:grid-cols-2">
          {[...data]
            .sort((a, b) => a.order - b.order)
            .map((saga) => (
              <li key={saga.id}>
                <SagaCard saga={saga} onOpen={() => navigateWithTransition(`/sagas/${saga.id}`)} />
              </li>
            ))}
        </ul>
      )}
    </div>
  )
}

function SagaCard({ saga, onOpen }: { saga: SagaSummary; onOpen: () => void }) {
  /**
   * La paleta viene de la API, asi que se inyecta como variables CSS en vez de
   * escribir colores en el codigo.
   *
   * `viewTransitionName` marca este bloque como el mismo elemento que la
   * cabecera de la historia: con View Transition API, uno se transforma en el
   * otro al navegar. Sin soporte, la propiedad se ignora y no pasa nada.
   */
  const style: CSSProperties & Record<string, string> = {
    '--stage-bg': saga.palette.background,
    '--stage-surface': saga.palette.surface,
    '--stage-primary': saga.palette.primary,
    '--stage-accent': saga.palette.accent,
    '--stage-text': saga.palette.text,
    backgroundColor: saga.palette.surface,
    color: saga.palette.text,
    viewTransitionName: `saga-${saga.id}`,
  }

  return (
    <button
      type="button"
      onClick={onOpen}
      style={style}
      className="w-full rounded-2xl p-6 text-left ring-1 ring-white/10 transition hover:ring-2 hover:ring-[var(--stage-accent)] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[var(--stage-accent)]"
    >
      <p
        className="text-xs font-semibold tracking-[0.2em] uppercase"
        style={{ color: saga.palette.primary }}
      >
        Saga {saga.order}
      </p>
      <h2 className="mt-2 text-xl font-semibold tracking-tight">{saga.title}</h2>
      <p className="mt-1 text-sm opacity-80">{saga.subtitle}</p>
      <p className="mt-4 text-sm leading-relaxed opacity-90">{saga.synopsis}</p>

      <dl className="mt-5 grid grid-cols-3 gap-3 text-xs">
        <div>
          <dt className="opacity-60">Etapas</dt>
          <dd className="mt-0.5 font-mono text-base">{saga.stageCount}</dd>
        </div>
        <div>
          <dt className="opacity-60">Distancia</dt>
          <dd className="mt-0.5 font-mono text-base">{formatNumber(saga.totalDistanceNm)} mn</dd>
        </div>
        <div className="min-w-0">
          <dt className="opacity-60">Ruta</dt>
          <dd className="mt-0.5 truncate">
            {saga.firstIsland} → {saga.lastIsland}
          </dd>
        </div>
      </dl>

      <p className="mt-5 text-sm font-medium" style={{ color: saga.palette.accent }}>
        Leer la saga →
      </p>
    </button>
  )
}
