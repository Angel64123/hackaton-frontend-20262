import type {
  CrewRole,
  FruitFilter,
  NewsPriority,
  NewsStatus,
  NewsType,
  WantedSort,
  WantedStatus,
} from './types'

const numberFormat = new Intl.NumberFormat('es-PE')

/** Recompensas en berries: 1250000000 -> "1 250 000 000". */
export function formatBerries(value: number): string {
  return numberFormat.format(value)
}

export function formatNumber(value: number): string {
  return numberFormat.format(value)
}

/** Version corta para tarjetas: 1250000000 -> "1.25 B". */
export function formatCompactBerries(value: number): string {
  if (value >= 1_000_000_000) return `${(value / 1_000_000_000).toFixed(2)} B`
  if (value >= 1_000_000) return `${(value / 1_000_000).toFixed(1)} M`
  if (value >= 1_000) return `${(value / 1_000).toFixed(0)} K`
  return numberFormat.format(value)
}

const dateTimeFormat = new Intl.DateTimeFormat('es-PE', {
  dateStyle: 'medium',
  timeStyle: 'short',
})

const dateFormat = new Intl.DateTimeFormat('es-PE', { dateStyle: 'medium' })

/** Las fechas llegan en ISO 8601 UTC. Si vienen raras, devolvemos el texto crudo. */
export function formatDateTime(iso: string | null): string {
  if (!iso) return '—'
  const date = new Date(iso)
  return Number.isNaN(date.getTime()) ? iso : dateTimeFormat.format(date)
}

export function formatDate(iso: string | null): string {
  if (!iso) return '—'
  const date = new Date(iso)
  return Number.isNaN(date.getTime()) ? iso : dateFormat.format(date)
}

/* ---------- etiquetas en espanol para los enums ---------- */

export const WANTED_STATUS_LABEL: Record<WantedStatus, string> = {
  AT_LARGE: 'Prófugo',
  CAPTURED: 'Capturado',
  MISSING: 'Desaparecido',
}

export const FRUIT_FILTER_LABEL: Record<FruitFilter, string> = {
  PARAMECIA: 'Paramecia',
  ZOAN: 'Zoan',
  LOGIA: 'Logia',
  NONE: 'Sin fruta',
}

export const CREW_ROLE_LABEL: Record<CrewRole, string> = {
  CAPTAIN: 'Capitán',
  FIRST_MATE: 'Primer oficial',
  NAVIGATOR: 'Navegante',
  SNIPER: 'Tirador',
  COOK: 'Cocinero',
  DOCTOR: 'Médico',
  SHIPWRIGHT: 'Carpintero',
  MUSICIAN: 'Músico',
  ARCHAEOLOGIST: 'Arqueólogo',
  HELMSMAN: 'Timonel',
  FIGHTER: 'Luchador',
}

export const NEWS_TYPE_LABEL: Record<NewsType, string> = {
  BOUNTY_UPDATE: 'Recompensas',
  BATTLE: 'Combate',
  MARINE_OPERATION: 'Operación de la Marina',
  WORLD_GOVERNMENT: 'Gobierno Mundial',
  DISCOVERY: 'Descubrimiento',
}

export const NEWS_PRIORITY_LABEL: Record<NewsPriority, string> = {
  LOW: 'Baja',
  MEDIUM: 'Media',
  HIGH: 'Alta',
  CRITICAL: 'Crítica',
}

export const NEWS_STATUS_LABEL: Record<NewsStatus, string> = {
  RUMOR: 'Rumor',
  CONFIRMED: 'Confirmada',
  DEBUNKED: 'Desmentida',
}

export const WANTED_SORT_LABEL: Record<WantedSort, string> = {
  'bounty,desc': 'Mayor recompensa',
  'name,asc': 'Nombre (A-Z)',
  'updatedAt,desc': 'Actualizados primero',
}

/* ---------- clases de color por estado ---------- */

export const WANTED_STATUS_CLASS: Record<WantedStatus, string> = {
  AT_LARGE: 'bg-rose-500/15 text-rose-200 ring-rose-500/30',
  CAPTURED: 'bg-emerald-500/15 text-emerald-200 ring-emerald-500/30',
  MISSING: 'bg-amber-500/15 text-amber-200 ring-amber-500/30',
}

export const NEWS_STATUS_CLASS: Record<NewsStatus, string> = {
  RUMOR: 'bg-amber-500/15 text-amber-200 ring-amber-500/30',
  CONFIRMED: 'bg-emerald-500/15 text-emerald-200 ring-emerald-500/30',
  DEBUNKED: 'bg-slate-500/15 text-slate-300 ring-slate-400/30',
}

export const NEWS_PRIORITY_CLASS: Record<NewsPriority, string> = {
  LOW: 'bg-slate-500/15 text-slate-300 ring-slate-400/30',
  MEDIUM: 'bg-sky-500/15 text-sky-200 ring-sky-500/30',
  HIGH: 'bg-orange-500/15 text-orange-200 ring-orange-500/30',
  CRITICAL: 'bg-rose-500/15 text-rose-200 ring-rose-500/30',
}
