// Tipos copiados del contrato publico de la API (Swagger /docs).
// Las listas `as const` sirven dos propositos: generar el tipo union y poder
// validar en tiempo de ejecucion los valores que llegan por la URL.

/* ---------- enums del contrato ---------- */

export const WANTED_STATUSES = ['AT_LARGE', 'CAPTURED', 'MISSING'] as const
export type WantedStatus = (typeof WANTED_STATUSES)[number]

/** Tipos reales de fruta que puede traer un cartel. */
export const FRUIT_TYPES = ['PARAMECIA', 'ZOAN', 'LOGIA'] as const
export type FruitType = (typeof FRUIT_TYPES)[number]

/** Valores aceptados por el filtro `fruit`: incluye NONE (sin fruta). */
export const FRUIT_FILTERS = ['PARAMECIA', 'ZOAN', 'LOGIA', 'NONE'] as const
export type FruitFilter = (typeof FRUIT_FILTERS)[number]

export const CREW_ROLES = [
  'CAPTAIN',
  'FIRST_MATE',
  'NAVIGATOR',
  'SNIPER',
  'COOK',
  'DOCTOR',
  'SHIPWRIGHT',
  'MUSICIAN',
  'ARCHAEOLOGIST',
  'HELMSMAN',
  'FIGHTER',
] as const
export type CrewRole = (typeof CREW_ROLES)[number]

export const NEWS_TYPES = [
  'BOUNTY_UPDATE',
  'BATTLE',
  'MARINE_OPERATION',
  'WORLD_GOVERNMENT',
  'DISCOVERY',
] as const
export type NewsType = (typeof NEWS_TYPES)[number]

export const NEWS_PRIORITIES = ['LOW', 'MEDIUM', 'HIGH', 'CRITICAL'] as const
export type NewsPriority = (typeof NEWS_PRIORITIES)[number]

export const NEWS_STATUSES = ['RUMOR', 'CONFIRMED', 'DEBUNKED'] as const
export type NewsStatus = (typeof NEWS_STATUSES)[number]

/** Estados a los que se puede pasar un rumor. */
export const NEWS_VERDICTS = ['CONFIRMED', 'DEBUNKED'] as const
export type NewsVerdict = (typeof NEWS_VERDICTS)[number]

export const LOG_POSE_STATUSES = ['LOCKED', 'UNLOCKED'] as const
export type LogPoseStatus = (typeof LOG_POSE_STATUSES)[number]

/* ---------- parametros de /wanted ---------- */

export const WANTED_SORTS = ['bounty,desc', 'name,asc', 'updatedAt,desc'] as const
export type WantedSort = (typeof WANTED_SORTS)[number]

export const PAGE_SIZES = [10, 20, 50] as const
export type PageSize = (typeof PAGE_SIZES)[number]

/** Defaults del contrato. */
export const DEFAULT_SORT: WantedSort = 'bounty,desc'
export const DEFAULT_SIZE: PageSize = 20
/** `q` busca en name y epithet; el contrato lo limita a 80 caracteres. */
export const MAX_QUERY_LENGTH = 80

/* ---------- auth ---------- */

export interface User {
  id: string
  name: string
  email: string
}

export interface Team {
  code: string
  name: string
}

export interface LoginResponse {
  token: string
  tokenType: 'Bearer'
  expiresAt: string
  user: User
  team: Team
}

export interface MeResponse {
  user: User
  team: Team
  expiresAt: string
}

/* ---------- log pose y dashboard ---------- */

export interface LogPose {
  status: LogPoseStatus
  grandLineUnlocked: boolean
  unlockedAt: string | null
  message: string
}

export interface Crew {
  id: string
  name: string
  shipName: string
  jollyRogerColor: string
  memberCount: number
  totalBounty: number
}

export interface DashboardSummary {
  team: Team
  wanted: {
    total: number
    totalBounty: number
    averageBounty: number
    byStatus: Record<WantedStatus, number>
    byFruit: Record<FruitType | 'NONE', number>
  }
  crews: {
    total: number
    mostWanted: Crew | null
  }
  topBounties: WantedSummary[]
  generatedAt: string
}

/* ---------- carteles ---------- */

export interface CrewRef {
  id: string
  name: string
}

export interface DevilFruit {
  name: string
  type: FruitType
}

export interface WantedSummary {
  id: string
  name: string
  epithet: string
  bounty: number
  status: WantedStatus
  crew: CrewRef
  role: CrewRole
  devilFruit: DevilFruit | null
  threatLevel: number
  lastSeenIsland: string
  updatedAt: string
}

export interface WantedDetail extends WantedSummary {
  age: number
  heightCm: number
  bio: string
  lastSeen: {
    island: string
    seenAt: string
  }
  bountyHistory: Array<{
    amount: number
    issuedAt: string
  }>
}

export interface WantedPage {
  content: WantedSummary[]
  totalElements: number
  totalPages: number
  page: number
  size: number
}

/* ---------- noticias ---------- */

export interface NewsItem {
  id: string
  type: NewsType
  priority: NewsPriority
  status: NewsStatus
  title: string
  summary: string
  source: string
  island: string
  relatedWanted: { id: string; name: string }
  publishedAt: string
  updatedAt: string
  verifiedAt: string | null
}

export interface NewsDetail extends NewsItem {
  /** Parrafos del cuerpo de la noticia. */
  body: string[]
}

export interface NewsFeed {
  items: NewsItem[]
  nextCursor: string | null
  hasMore: boolean
}

/* ---------- sagas ---------- */

export interface Palette {
  background: string
  surface: string
  primary: string
  accent: string
  text: string
}

export const STAGE_METRIC_KEYS = [
  'distanceNm',
  'crewMorale',
  'bountyPool',
  'marineThreat',
] as const
export type StageMetricKey = (typeof STAGE_METRIC_KEYS)[number]

export interface StageMetric {
  key: StageMetricKey
  label: string
  value: number
  unit: string
}

export interface SagaIsland {
  id: string
  name: string
  /** Posicion horizontal dentro de map.width. */
  x: number
  /** Posicion vertical dentro de map.height (0 = arriba). */
  y: number
}

export interface SagaStage {
  id: string
  order: number
  slug: string
  title: string
  narrative: string[]
  island: SagaIsland
  palette: Palette
  metrics: StageMetric[]
}

export interface SagaSummary {
  id: string
  order: number
  title: string
  subtitle: string
  synopsis: string
  stageCount: number
  totalDistanceNm: number
  firstIsland: string
  lastIsland: string
  palette: Palette
}

export interface SagaStory {
  saga: SagaSummary & { intro: string }
  map: { width: number; height: number }
  stages: SagaStage[]
}

/* ---------- errores ---------- */

export interface ApiFieldError {
  field: string
  message: string
}

/** Cuerpo de error unico de la API, igual en todas las rutas. */
export interface ApiErrorBody {
  status: number
  code: string
  message: string
  traceId: string
  details?: ApiFieldError[]
  retryAfterSeconds?: number
  /** En 409 NEWS_ALREADY_VERIFIED: la noticia tal como esta ahora. */
  current?: NewsDetail
}
