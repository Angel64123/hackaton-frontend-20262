import { NEWS_PRIORITIES, NEWS_STATUSES, NEWS_TYPES } from './types'
import type { NewsPriority, NewsStatus, NewsType } from './types'

/** Filtros del feed. Viven en la URL, igual que en el CP2. */
export interface NewsFilters {
  type: NewsType | null
  priority: NewsPriority | null
  status: NewsStatus | null
}

export const EMPTY_FILTERS: NewsFilters = { type: null, priority: null, status: null }

/** El contrato permite hasta 30; 20 es el default. */
export const NEWS_PAGE_LIMIT = 20

function pickEnum<T extends string>(raw: string | null, allowed: readonly T[]): T | null {
  if (!raw) return null
  return (allowed as readonly string[]).includes(raw) ? (raw as T) : null
}

/** Un valor fuera del contrato se ignora en vez de viajar a la API. */
export function parseNewsFilters(params: URLSearchParams): NewsFilters {
  return {
    type: pickEnum(params.get('type'), NEWS_TYPES),
    priority: pickEnum(params.get('priority'), NEWS_PRIORITIES),
    status: pickEnum(params.get('status'), NEWS_STATUSES),
  }
}

/**
 * Identidad de los filtros. El cursor queda ligado a los filtros con los que
 * se pidio: si esta clave cambia, el cursor acumulado ya no sirve y el feed
 * tiene que empezar de cero.
 */
export function newsFilterKey(filters: NewsFilters): string {
  return [filters.type ?? '', filters.priority ?? '', filters.status ?? ''].join('|')
}

export function newsSearchString(filters: NewsFilters): string {
  const params = new URLSearchParams()
  if (filters.type) params.set('type', filters.type)
  if (filters.priority) params.set('priority', filters.priority)
  if (filters.status) params.set('status', filters.status)
  const serialized = params.toString()
  return serialized ? `?${serialized}` : ''
}

export function hasNewsFilters(filters: NewsFilters): boolean {
  return Boolean(filters.type || filters.priority || filters.status)
}
