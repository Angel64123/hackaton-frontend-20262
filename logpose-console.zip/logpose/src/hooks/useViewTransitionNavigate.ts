import { useCallback } from 'react'
import { flushSync } from 'react-dom'
import { useNavigate } from 'react-router-dom'
import { usePrefersReducedMotion } from './usePrefersReducedMotion'

type ViewTransitionStarter = (callback: () => void) => unknown

/**
 * Devuelve document.startViewTransition solo si el navegador la trae.
 * Se comprueba en tiempo de ejecucion porque no todos los navegadores la
 * soportan todavia, aunque los tipos del DOM ya la declaren.
 */
function getViewTransitionStarter(): ViewTransitionStarter | null {
  if (typeof document === 'undefined') return null
  const candidate = (document as unknown as Record<string, unknown>).startViewTransition
  if (typeof candidate !== 'function') return null
  return (candidate as ViewTransitionStarter).bind(document)
}

/**
 * Navega con View Transition API cuando existe soporte, y con una navegacion
 * normal cuando no (CP5).
 *
 * `flushSync` es necesario porque la transicion necesita que el DOM ya haya
 * cambiado dentro del callback; React, por defecto, aplicaria el cambio
 * despues y la transicion capturaria el estado viejo.
 *
 * Con prefers-reduced-motion se salta la transicion a proposito.
 */
export function useViewTransitionNavigate(): (to: string) => void {
  const navigate = useNavigate()
  const prefersReducedMotion = usePrefersReducedMotion()

  return useCallback(
    (to: string) => {
      const start = getViewTransitionStarter()

      if (prefersReducedMotion || !start) {
        navigate(to)
        return
      }

      start(() => {
        flushSync(() => {
          navigate(to)
        })
      })
    },
    [navigate, prefersReducedMotion],
  )
}
