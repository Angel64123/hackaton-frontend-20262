/**
 * Deteccion de soporte de CSS Scroll-driven Animations.
 *
 * Si el navegador la soporta, el CSS maneja la barra de progreso y la entrada
 * de cada etapa (dentro de @supports). Si no, estos valores dejan que React
 * calcule lo mismo con un listener de scroll: comportamiento equivalente.
 */

function supports(property: string, value: string): boolean {
  if (typeof CSS === 'undefined' || typeof CSS.supports !== 'function') return false
  return CSS.supports(`${property}: ${value}`)
}

/** Se evalua una vez: el soporte del navegador no cambia durante la sesion. */
export const SUPPORTS_SCROLL_TIMELINE: boolean = supports('animation-timeline', 'scroll()')

export const SUPPORTS_VIEW_TIMELINE: boolean = supports('animation-timeline', 'view()')
