import type { SagaStage } from '../lib/types'

interface SagaMapProps {
  map: { width: number; height: number }
  stages: SagaStage[]
  activeIndex: number
  /** Fraccion de la ruta ya recorrida, de 0 a 1. */
  routeProgress: number
}

/**
 * Mapa persistente del Grand Line, dibujado con SVG a partir de las
 * coordenadas que da la API (island.x, island.y dentro de map.width x map.height).
 *
 * No es un video ni un canvas pregrabado: cada isla, la ruta y la posicion del
 * barco salen de los datos de /sagas/{id}/story.
 */
export function SagaMap({ map, stages, activeIndex, routeProgress }: SagaMapProps) {
  const points = stages.map((stage) => ({ x: stage.island.x, y: stage.island.y }))
  const activeStage = stages[activeIndex]

  // Un unico trazo por todas las islas, en orden de recorrido.
  const routePath = points
    .map((point, index) => `${index === 0 ? 'M' : 'L'} ${point.x} ${point.y}`)
    .join(' ')

  // Escala para que los trazos y los textos se vean igual en mapas de
  // cualquier tamano: todo se mide en unidades del viewBox.
  const unit = Math.max(map.width, map.height) / 100

  return (
    <svg
      viewBox={`0 0 ${map.width} ${map.height}`}
      preserveAspectRatio="xMidYMid meet"
      className="h-full w-full"
      role="img"
      aria-label={
        activeStage
          ? `Mapa del recorrido. Etapa ${activeIndex + 1} de ${stages.length}: ${activeStage.island.name}.`
          : 'Mapa del recorrido.'
      }
    >
      <defs>
        <radialGradient id="sea" cx="50%" cy="45%" r="75%">
          <stop offset="0%" stopColor="var(--stage-surface)" stopOpacity="0.9" />
          <stop offset="100%" stopColor="var(--stage-bg)" stopOpacity="1" />
        </radialGradient>
      </defs>

      <rect width={map.width} height={map.height} fill="url(#sea)" rx={unit * 2} />

      {/* Ruta completa, de fondo: se ve a donde lleva el viaje. */}
      <path
        d={routePath}
        fill="none"
        stroke="var(--stage-text)"
        strokeOpacity={0.18}
        strokeWidth={unit * 0.5}
        strokeDasharray={`${unit * 2} ${unit * 1.5}`}
        strokeLinecap="round"
      />

      {/*
        Ruta recorrida. pathLength={1} normaliza el largo del trazo a 1, asi
        strokeDashoffset puede ir de 1 (nada dibujado) a 0 (todo dibujado)
        sin tener que medir el path en pixeles.
      */}
      <path
        className="map-route"
        d={routePath}
        pathLength={1}
        fill="none"
        stroke="var(--stage-accent)"
        strokeWidth={unit * 0.8}
        strokeLinecap="round"
        strokeDasharray={1}
        strokeDashoffset={1 - routeProgress}
      />

      {stages.map((stage, index) => {
        const visited = index <= activeIndex
        const isActive = index === activeIndex
        return (
          <g key={stage.id}>
            {isActive && (
              <circle
                cx={stage.island.x}
                cy={stage.island.y}
                r={unit * 3.2}
                fill="var(--stage-accent)"
                fillOpacity={0.18}
              />
            )}
            <circle
              cx={stage.island.x}
              cy={stage.island.y}
              r={isActive ? unit * 1.7 : unit * 1.1}
              fill={visited ? 'var(--stage-primary)' : 'var(--stage-bg)'}
              stroke={isActive ? 'var(--stage-accent)' : 'var(--stage-primary)'}
              strokeWidth={unit * 0.35}
            />
            <text
              x={stage.island.x}
              y={stage.island.y - unit * 2.6}
              textAnchor="middle"
              fill="var(--stage-text)"
              fillOpacity={isActive ? 0.95 : 0.4}
              fontSize={unit * (isActive ? 2.6 : 2.1)}
              fontWeight={isActive ? 600 : 400}
            >
              {stage.island.name}
            </text>
          </g>
        )
      })}

      {/* El barco se coloca en la isla de la etapa activa. */}
      {activeStage && (
        <g
          className="map-ship"
          style={{
            transform: `translate(${activeStage.island.x}px, ${activeStage.island.y}px)`,
          }}
        >
          <path
            d={`M ${-unit * 1.6} 0 L ${unit * 1.6} 0 L ${unit * 1} ${unit * 1.2} L ${-unit * 1} ${unit * 1.2} Z`}
            fill="var(--stage-text)"
          />
          <path
            d={`M 0 ${-unit * 2.8} L ${unit * 1.5} ${-unit * 0.3} L 0 ${-unit * 0.3} Z`}
            fill="var(--stage-accent)"
          />
          <line
            x1={0}
            y1={-unit * 3}
            x2={0}
            y2={0}
            stroke="var(--stage-text)"
            strokeWidth={unit * 0.3}
          />
        </g>
      )}
    </svg>
  )
}
