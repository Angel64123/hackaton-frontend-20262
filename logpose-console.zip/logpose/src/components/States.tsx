import type { ReactNode } from 'react'
import { Link } from 'react-router-dom'
import type { ParsedApiError } from '../lib/api'

/** Pantalla de espera mientras se verifica la sesion. No es el login. */
export function SplashScreen({ message }: { message: string }) {
  return (
    <div className="grid min-h-screen place-items-center bg-slate-950 px-4">
      <div className="flex flex-col items-center gap-4 text-center">
        <Compass className="h-10 w-10 animate-spin-slow text-amber-300" />
        <p className="text-sm text-slate-300">{message}</p>
      </div>
    </div>
  )
}

export function Spinner({ className = 'h-5 w-5' }: { className?: string }) {
  return (
    <svg className={`${className} animate-spin`} viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <circle cx="12" cy="12" r="9" stroke="currentColor" strokeOpacity="0.25" strokeWidth="3" />
      <path
        d="M21 12a9 9 0 0 0-9-9"
        stroke="currentColor"
        strokeWidth="3"
        strokeLinecap="round"
      />
    </svg>
  )
}

export function Compass({ className = 'h-6 w-6' }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <circle cx="12" cy="12" r="9" stroke="currentColor" strokeWidth="1.5" />
      <path d="m15.2 8.8-2.1 4.3-4.3 2.1 2.1-4.3z" fill="currentColor" />
    </svg>
  )
}

/**
 * Estado de carga. `rows` dibuja esqueletos del alto de las filas reales para
 * que la lista no salte cuando llegan los datos (CP2: "sin mover el layout").
 */
export function LoadingState({ label = 'Cargando…', rows = 0 }: { label?: string; rows?: number }) {
  if (rows > 0) {
    return (
      <div className="space-y-3" role="status" aria-live="polite" aria-busy="true">
        <span className="sr-only">{label}</span>
        {Array.from({ length: rows }, (_, index) => (
          <div
            key={index}
            className="h-24 animate-pulse rounded-xl border border-white/5 bg-white/[0.03]"
          />
        ))}
      </div>
    )
  }

  return (
    <div
      className="flex items-center justify-center gap-3 py-12 text-sm text-slate-400"
      role="status"
      aria-live="polite"
    >
      <Spinner className="h-5 w-5 text-amber-300" />
      <span>{label}</span>
    </div>
  )
}

/** Error con reintento: lo piden el CP1, el CP2 y el CP4. */
export function ErrorState({
  error,
  onRetry,
  title = 'No pudimos cargar esta información',
}: {
  error: ParsedApiError
  onRetry?: () => void
  title?: string
}) {
  return (
    <div
      className="rounded-xl border border-rose-500/30 bg-rose-500/5 p-6 text-center"
      role="alert"
    >
      <p className="font-semibold text-rose-100">{title}</p>
      <p className="mt-2 text-sm text-rose-200/80">{error.message}</p>
      {error.retryAfterSeconds !== null && (
        <p className="mt-1 text-xs text-rose-200/60">
          Vuelve a intentar en {error.retryAfterSeconds} s.
        </p>
      )}
      {onRetry && (
        <button
          type="button"
          onClick={onRetry}
          className="mt-4 rounded-lg bg-rose-500/20 px-4 py-2 text-sm font-medium text-rose-50 ring-1 ring-rose-400/40 transition hover:bg-rose-500/30 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-rose-300"
        >
          Reintentar
        </button>
      )}
    </div>
  )
}

export function EmptyState({ title, hint }: { title: string; hint?: string }) {
  return (
    <div className="rounded-xl border border-white/10 bg-white/[0.02] p-10 text-center">
      <p className="font-medium text-slate-200">{title}</p>
      {hint && <p className="mt-2 text-sm text-slate-400">{hint}</p>}
    </div>
  )
}

/**
 * Bloqueo del Grand Line (423 LOG_POSE_REQUIRED). No es un error de la app:
 * es el estado esperado hasta aprobar la inspeccion del CP3.
 */
export function LogPoseLockedState({ message }: { message?: string }) {
  return (
    <div className="mx-auto max-w-xl rounded-2xl border border-amber-400/30 bg-amber-400/5 p-8 text-center">
      <Compass className="mx-auto h-10 w-10 text-amber-300" />
      <h2 className="mt-4 text-lg font-semibold text-amber-100">El Grand Line está cerrado</h2>
      <p className="mt-2 text-sm text-amber-200/80">
        {message ??
          'Este tramo necesita el Log Pose. La API responde 423 hasta aprobar la inspección de Reverse Mountain.'}
      </p>
      <Link
        to="/"
        className="mt-5 inline-block rounded-lg bg-amber-400/20 px-4 py-2 text-sm font-medium text-amber-50 ring-1 ring-amber-300/40 transition hover:bg-amber-400/30"
      >
        Volver al dashboard
      </Link>
    </div>
  )
}

export function Badge({ children, className = '' }: { children: ReactNode; className?: string }) {
  return (
    <span
      className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ring-1 ring-inset ${className}`}
    >
      {children}
    </span>
  )
}

export function FieldError({ message }: { message?: string }) {
  if (!message) return null
  return (
    <p className="mt-1.5 text-xs text-rose-300" role="alert">
      {message}
    </p>
  )
}
