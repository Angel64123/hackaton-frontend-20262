import { createContext, useCallback, useContext, useMemo, useRef, useState } from 'react'
import type { ReactNode } from 'react'
import { api, isAbort, isCursorProblem, parseApiError } from '../lib/api'
import type { ParsedApiError } from '../lib/api'
import { EMPTY_FILTERS, NEWS_PAGE_LIMIT, newsFilterKey } from '../lib/newsQuery'
import type { NewsFilters } from '../lib/newsQuery'
import type { NewsDetail, NewsFeed, NewsItem } from '../lib/types'

interface NewsFeedValue {
  filters: NewsFilters
  items: NewsItem[]
  hasMore: boolean
  loading: boolean
  error: ParsedApiError | null
  /** true cuando ya se pidio al menos una pagina con estos filtros. */
  initialized: boolean
  /** La pagina avisa de los filtros de la URL; el provider decide si reinicia. */
  syncFilters: (filters: NewsFilters) => void
  loadMore: () => void
  retry: () => void
  /** Refleja en el feed una noticia que cambio en el detalle. */
  applyNewsUpdate: (news: NewsDetail) => void
  /** Apunta la posicion del scroll mientras se navega el feed. */
  saveScroll: (value: number) => void
  /** Devuelve la ultima posicion apuntada, para restaurarla al volver. */
  getSavedScroll: () => number
}

const NewsFeedContext = createContext<NewsFeedValue | null>(null)

/** Concatena sin repetir ids: la Regla de Nami, nada se cuenta dos veces. */
function mergeUnique(previous: NewsItem[], incoming: NewsItem[]): NewsItem[] {
  const seen = new Set(previous.map((item) => item.id))
  const fresh = incoming.filter((item) => {
    if (seen.has(item.id)) return false
    seen.add(item.id)
    return true
  })
  return fresh.length === 0 ? previous : previous.concat(fresh)
}

/**
 * Estado del feed de noticias.
 *
 * Vive aqui y no en la pagina a proposito: al abrir el detalle de una noticia
 * la pagina del feed se desmonta, y si el estado viviera en ella se perderian
 * las paginas ya cargadas. Montado por encima de las rutas, volver del detalle
 * no cuesta ni una request.
 */
export function NewsFeedProvider({ children }: { children: ReactNode }) {
  const [filters, setFilters] = useState<NewsFilters>(EMPTY_FILTERS)
  const [items, setItems] = useState<NewsItem[]>([])
  const [hasMore, setHasMore] = useState(true)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<ParsedApiError | null>(null)
  const [initialized, setInitialized] = useState(false)

  /**
   * La posicion del scroll vive en un ref, no en el estado: se actualiza en
   * cada frame de scroll y guardarla en el estado volveria a renderizar todo
   * el feed decenas de veces por segundo.
   */
  const scrollYRef = useRef(0)

  /**
   * Generacion de la carga actual. Cada request se guarda la generacion con la
   * que salio; al volver, si la generacion ya cambio (los filtros son otros),
   * la respuesta se descarta. Es lo que impide mezclar resultados de filtros
   * distintos cuando se cambia un filtro con una carga en vuelo.
   */
  const epochRef = useRef(0)
  /** Candado: solo una carga adicional en vuelo a la vez. */
  const inFlightRef = useRef(false)
  const controllerRef = useRef<AbortController | null>(null)
  const cursorRef = useRef<string | null>(null)
  const hasMoreRef = useRef(true)
  const errorRef = useRef<ParsedApiError | null>(null)
  const filtersRef = useRef<NewsFilters>(EMPTY_FILTERS)
  const filterKeyRef = useRef<string>(newsFilterKey(EMPTY_FILTERS))
  /** Evita reintentar en bucle si el cursor sigue fallando. */
  const cursorRecoveredRef = useRef(false)

  const setErrorBoth = useCallback((value: ParsedApiError | null) => {
    errorRef.current = value
    setError(value)
  }, [])

  const setHasMoreBoth = useCallback((value: boolean) => {
    hasMoreRef.current = value
    setHasMore(value)
  }, [])

  const load = useCallback(
    (mode: 'fresh' | 'more') => {
      if (inFlightRef.current) return
      if (mode === 'more') {
        if (!hasMoreRef.current) return
        // Con un error en pantalla no se reintenta solo: el observer seguiria
        // disparando y mandaria una request tras otra. Espera al boton.
        if (errorRef.current) return
        if (!cursorRef.current) return
      }

      const epoch = epochRef.current
      const controller = new AbortController()
      controllerRef.current = controller
      inFlightRef.current = true
      setLoading(true)
      setErrorBoth(null)

      const params: Record<string, string | number> = { limit: NEWS_PAGE_LIMIT }
      const current = filtersRef.current
      if (current.type) params.type = current.type
      if (current.priority) params.priority = current.priority
      if (current.status) params.status = current.status
      if (mode === 'more' && cursorRef.current) params.cursor = cursorRef.current

      api
        .get<NewsFeed>('/news/feed', { params, signal: controller.signal })
        .then((response) => {
          if (epoch !== epochRef.current) return

          cursorRef.current = response.data.nextCursor
          setHasMoreBoth(response.data.hasMore && response.data.nextCursor !== null)
          setItems((previous) =>
            mode === 'fresh'
              ? mergeUnique([], response.data.items)
              : mergeUnique(previous, response.data.items),
          )
          setInitialized(true)
          cursorRecoveredRef.current = false
        })
        .catch((err: unknown) => {
          if (epoch !== epochRef.current || isAbort(err)) return

          const parsed = parseApiError(err)

          // El cursor dejo de ser valido (alterado o usado con otros filtros):
          // el contrato dice pedir el feed sin cursor. Se recupera una sola vez.
          if (isCursorProblem(parsed) && !cursorRecoveredRef.current) {
            cursorRecoveredRef.current = true
            cursorRef.current = null
            setHasMoreBoth(true)
            inFlightRef.current = false
            setLoading(false)
            load('fresh')
            return
          }

          // En un error al cargar mas, las noticias ya cargadas se quedan:
          // solo se muestra el aviso con reintento al final de la lista.
          setErrorBoth(parsed)
          setInitialized(true)
        })
        .finally(() => {
          if (epoch !== epochRef.current) return
          inFlightRef.current = false
          setLoading(false)
        })
    },
    [setErrorBoth, setHasMoreBoth],
  )

  const resetAndLoad = useCallback(
    (next: NewsFilters) => {
      // Nueva generacion: cualquier respuesta en camino queda invalidada.
      epochRef.current += 1
      controllerRef.current?.abort()
      controllerRef.current = null
      inFlightRef.current = false

      filtersRef.current = next
      filterKeyRef.current = newsFilterKey(next)
      cursorRef.current = null
      cursorRecoveredRef.current = false

      setFilters(next)
      setItems([])
      setHasMoreBoth(true)
      setErrorBoth(null)
      setInitialized(false)
      // Filtros nuevos, lista nueva: la posicion anterior ya no significa nada.
      scrollYRef.current = 0

      load('fresh')
    },
    [load, setErrorBoth, setHasMoreBoth],
  )

  /**
   * La pagina llama a esto con los filtros de la URL. Si son los mismos que ya
   * tiene cargados, no se pide nada: asi volver del detalle reutiliza el feed.
   */
  const syncFilters = useCallback(
    (next: NewsFilters) => {
      const nextKey = newsFilterKey(next)
      if (nextKey === filterKeyRef.current && initialized) return
      if (nextKey === filterKeyRef.current && inFlightRef.current) return
      resetAndLoad(next)
    },
    [initialized, resetAndLoad],
  )

  const loadMore = useCallback(() => {
    load('more')
  }, [load])

  const retry = useCallback(() => {
    setErrorBoth(null)
    // Si fallo la primera carga no hay cursor todavia: hay que empezar de cero.
    load(cursorRef.current ? 'more' : 'fresh')
  }, [load, setErrorBoth])

  const applyNewsUpdate = useCallback((news: NewsDetail) => {
    setItems((previous) => {
      const index = previous.findIndex((item) => item.id === news.id)
      if (index === -1) return previous

      const activeStatus = filtersRef.current.status
      // Con un filtro de estado activo, una noticia que ya no lo cumple sale
      // de la lista: el feed no puede contradecir su propio filtro.
      if (activeStatus && news.status !== activeStatus) {
        return previous.filter((item) => item.id !== news.id)
      }

      const next = previous.slice()
      next[index] = { ...previous[index], ...news }
      return next
    })
  }, [])

  const saveScroll = useCallback((value: number) => {
    scrollYRef.current = value
  }, [])

  const getSavedScroll = useCallback(() => scrollYRef.current, [])

  const value = useMemo<NewsFeedValue>(
    () => ({
      filters,
      items,
      hasMore,
      loading,
      error,
      initialized,
      syncFilters,
      loadMore,
      retry,
      applyNewsUpdate,
      saveScroll,
      getSavedScroll,
    }),
    [
      filters,
      items,
      hasMore,
      loading,
      error,
      initialized,
      syncFilters,
      loadMore,
      retry,
      applyNewsUpdate,
      saveScroll,
      getSavedScroll,
    ],
  )

  return <NewsFeedContext.Provider value={value}>{children}</NewsFeedContext.Provider>
}

export function useNewsFeed(): NewsFeedValue {
  const value = useContext(NewsFeedContext)
  if (!value) {
    throw new Error('useNewsFeed debe usarse dentro de <NewsFeedProvider>.')
  }
  return value
}
