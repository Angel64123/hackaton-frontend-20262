import { Route, Routes } from 'react-router-dom'
import { RequireAuth } from './auth/RequireAuth'
import { Layout } from './components/Layout'
import { LogPoseProvider } from './logpose/LogPoseContext'
import { NewsFeedProvider } from './news/NewsFeedContext'
import { LoginPage } from './pages/LoginPage'
import { RegisterPage } from './pages/RegisterPage'
import { DashboardPage } from './pages/DashboardPage'
import { WantedListPage } from './pages/WantedListPage'
import { WantedDetailPage } from './pages/WantedDetailPage'
import { NewsFeedPage } from './pages/NewsFeedPage'
import { NewsDetailPage } from './pages/NewsDetailPage'
import { SagasPage } from './pages/SagasPage'
import { SagaStoryPage } from './pages/SagaStoryPage'
import { NotFoundPage } from './pages/NotFoundPage'

/**
 * Los providers del Log Pose y del feed se montan por encima de las rutas
 * privadas, no dentro de cada pagina. Asi el feed del CP4 sobrevive al ir al
 * detalle de una noticia y volver: el componente de la lista se desmonta, pero
 * el estado vive en el provider, que sigue montado.
 */
function PrivateShell() {
  return (
    <LogPoseProvider>
      <NewsFeedProvider>
        <Layout />
      </NewsFeedProvider>
    </LogPoseProvider>
  )
}

export function App() {
  return (
    <Routes>
      <Route path="/login" element={<LoginPage />} />
      <Route path="/register" element={<RegisterPage />} />

      <Route element={<RequireAuth />}>
        <Route element={<PrivateShell />}>
          <Route index element={<DashboardPage />} />
          <Route path="wanted" element={<WantedListPage />} />
          <Route path="wanted/:id" element={<WantedDetailPage />} />
          <Route path="news" element={<NewsFeedPage />} />
          <Route path="news/:id" element={<NewsDetailPage />} />
          <Route path="sagas" element={<SagasPage />} />
          <Route path="sagas/:id" element={<SagaStoryPage />} />
        </Route>
      </Route>

      {/* La 404 vive fuera de las rutas privadas: una direccion que no existe
          no es un problema de sesion, asi que no manda a nadie al login. */}
      <Route path="*" element={<NotFoundPage />} />
    </Routes>
  )
}
